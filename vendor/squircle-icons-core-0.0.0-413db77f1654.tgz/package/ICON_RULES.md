# Icon — Shared Agent Playbook

Maintained: 2026-10-28. **This is the canonical English working document for icon creation and revision across this workspace.** It defines the goal, rules, design contract, workflow, verification, tests and completion criteria. Read it before making icon changes. Update the current sections when the owner changes a rule; do not maintain competing copies in agent entry points.

## Current design direction — original squircle identity

The owner clarified that this project needs its **own squircle design language**, beyond ordinary rounded corners. The concept-first documentation task is complete. On2026-10-28 the owner authorized the first **Camera-only artwork trial**, including Outline/Filled and a working local Lab preview. This does not authorize a collection-wide redesign.

An external example may reveal a mismatch between our work and our own brief. It must not supply the design solution. Do not trace, extract, sample or reconstruct its paths, silhouettes, proportions, motifs, compositions, icon inventory or style recipes. Do not make a slightly altered version of another collection. Common primitives such as a square, circle and independently constructed squircle may naturally resemble each other; do not invent arbitrary differences merely to make a basic shape unusual. Use our own accepted Square and our own mathematical construction. The object silhouettes, linework, tabs, openings, spacing and other distinguishing solutions must be developed independently. Start our design decisions from the meaning of each icon and independently develop our own shape grammar.

The existing circular-corner measurements below describe the approved implementation baseline. They do not establish the future squircle language. No new curve formula, exponent, control-point recipe or replacement geometry is approved by this conceptual clarification. Preserve the current artwork and acceptance records until a later artwork request establishes the scope of a redesign.

## Base shape first; new-design stroke1.5 — 2026-10-28

The owner requested a base squircle study, then explicitly expanded it to three subject prototypes: **Folder, Camera and Square**. Review these together before extending the collection redesign. A rounded square and a squircle must read differently: the former has explicit straight sides joined by local circular fillets; the study develops its whole contour continuously toward its corners. Develop our own proportions. External screenshots clarify the distinction but are not shape templates.

**New-design base stroke is1.5 native units.** The owner explicitly scoped this to the shape study and future redesign work first. Do not change the existing collection's1.75 default, palette, Filled contours or morph weights as part of this study. Existing Camera remains the earlier1.75 draft; its shape is not the approved base grammar.

The standalone Lab shape study uses a native24×24 canvas, centered12,12, with visible bounds2..22 in both styles. The whole-contour trial is a mathematically constructed superellipse with an adjustable profile; its Balanced3.2 Square contour is now owner-accepted and leans more circular than the4-power reference; that acceptance is not a universal formula for semantic details. Outline centerlines are the inward normal offset of the Filled exterior by.75, rather than a scaled copy; export fitting error stays below.001 native units. Rounded-square and circle references use the same visible bounds and1.5 stroke for a fair comparison. The UI describes visual roundness; mathematical construction lives in this document and the Core design module.

This is one three-subject design-language study, not a request for six new production identities or for applying a frame to other icons. Keep it separate from the static catalog and approval counts. Square at Balanced and the scoped1.5 base are accepted; revised object drawings and any later production application remain subject to owner visual review. The study is authored in [Core](src/design/squircle-base.ts), promoted through the pinned adapter, and shown by the private local Lab. No runtime sibling-checkout imports or copied path implementations belong in Lab.

### Owner review: Balanced Square accepted; object tops rejected

On2026-10-28 the owner accepted the **Square base at Balanced (profile3.2, stroke1.5)**. Preserve its exact Outline/Filled geometry as the current shape reference. This approves that base contour, not every roundness setting, production enclosing frame, or a formula imposed on all object details.

Camera currently uses our own original silhouette at Core `310b780` with selective body-corner treatment; it remains a draft. Folder has moved beyond the rejected roof/cut-line upper trials: the owner accepted its Square-derived lower portion and clarified the upper construction with a sketch of overlapping squircle forms. Use our own Square curve language to build the large front body and smaller visible rear form. Original source geometry is a starting reference, not an immutable height/proportion requirement. Preserve accepted parts and finish the local prototype review before moving completed work to Figma.

### Folder lower portion accepted; upper squircle flow still under review

The owner accepted the **lower portion of the cut-Square Folder at Balanced3.2 and1.5** from the `2580318` study snapshot. Preserve its retained lower Square curves and native1.5 construction in both styles during the upper revision. The acceptance regression protects X coordinates and relative Y coordinates of the starting point and first64 lower cubics. Uniform optical recentering is allowed; anisotropic scaling or changing the accepted lower curve is not. Acceptance of the lower shape does not freeze its absolute Y placement or a historical divider position. This is a specific accepted part, not a universal height/proportion rule for other subjects or approval of the complete Folder.

The owner found the upper portion too deliberately straight, then supplied a sketch clarifying **overlapping squircles**: a large front body and a smaller rear squircle peeking above it as the tab. Construct those independently authored forms and their visible overlap. The front body's upper curve is a layer boundary; do not model the concept as an arbitrary wavy tab-to-shelf line or freeze the previous straight divider. Use coherent curve joins, correct occlusion and safe1.5 offsets. Retain the recognizable folder, interior clearance and original linework. The complete upper silhouette and overall Folder still require owner visual review; Camera and the accepted Square remain unchanged by this revision.

### Part-by-part design judgment — owner clarification

The owner explicitly clarified that icons must **not pursue maximum squircle treatment at every corner**. Evaluate the artwork piece by piece. Balanced Square is a reference for the family, not a contour or mathematical profile to force onto every subject or subpart.

Identify the body, housing, tab, opening, concave join and small detail separately. A semantic object may be constructed from several meaningful squircle forms and other primitives, with deliberate overlap and occlusion, rather than deforming a single contour to express every feature. Use the family curve where it suits the part's meaning, proportions and available space. Keep level edges, circles and appropriately fitted local transitions where those produce clearer shapes or safer clearance. A tiny join need not duplicate a full-size body corner. Do not create bulges, warped silhouettes, oversized corners or awkward roofs merely to satisfy one formula. Record an intentional local exception and its reason; judge the complete icon at actual sizes for coherence and recognition.

This clarifies the whole-contour study rather than discarding the accepted Balanced Square. Camera currently uses its own original silhouette with selective body-corner treatment; Folder derives from our own Square by cutting its upper portion; its lower part is now accepted and its upper flow is being refined. Both use1.5 weight and allow subject-specific proportions. No collection-wide or unrelated redraw is authorized by this clarification.

### Proportion freedom and Folder from our own Square — latest owner clarification

Do not turn reference dimensions or a previous prototype into self-imposed design limits. Each subject may need its own width, height, aspect ratio, occupied area, tab, roof and internal placement. The accepted Square guides the family curve and visual character; it does not prescribe the height of Camera, Folder or every other icon. A shared language comes from coherent stroke, curve transitions, spacing and optical weight across a row of icons. It does not require equal bounding boxes or one formula for all subjects.

The owner's concrete Folder direction is to use **our independently authored Square as a body and cut away or lower the upper portion to form a folder top/tab**. Retain the useful side/lower curves directly where appropriate, rather than vertically scaling the whole Square or stretching the previous Folder to a fixed height. Design the new upper linework and joins ourselves. Let the resulting silhouette determine its natural height and then judge recognition, balance and actual-size readability. The Square reference itself stays unchanged; a derived Folder is a separate draft.

Common basic shapes are legitimate starting primitives. Reference images explain principles and point out a problem; they do not provide paths, traced silhouettes, sampled proportions, line style or detail arrangements to copy. A square looking similar to another square is not a reason to deform our base. Semantic objects and their distinguishing construction require our own decisions.

Numerical draft dimensions below describe an implementation snapshot, not a permanent approval or prohibition on redesign. Tests must protect native stroke, contour correspondence, clear openings, finite joins, primary margins and explicitly accepted artwork. Do not freeze an unapproved Camera/Folder height or every historical control point merely because it was used in a draft. A curve-only UI control may still keep semantic parts stable within the current construction; that local behavior test must not be presented as an immutable rule for future designs.

### Folder as overlapping squircles — owner sketch

Model the Folder as **two meaningful squircle forms seen in overlap**: the larger front panel/body and the smaller rear form visible above its upper-left portion. Use our own accepted Square curve language and independently chosen proportions; the owner's rough sketch explains the construction, not coordinates to trace. The front form occludes the covered rear edges. Its curved top expresses the layer boundary. Develop the body and rear form as pieces before resolving the visible combined silhouette.

Do not substitute a decorative waving single outline for the two forms. Do not insist on flat roofs/shelves or a predetermined object height. Preserve the accepted lower body curve; uniformly repositioning the completed drawing for optical balance is allowed. Camera and the standalone Square are outside this Folder revision.

The current independent trial uses the accepted Square's64 lower cubics, a front upper squircle cap with native half-axes10/3.5 about12,12, and a rear squircle centered7.5,8.1 with half-axes4.4/3.2. Calculate their two intersections and resolve the visible union boundary. A uniform−1.45 Y recenter produces observed exterior boundsx2..22/y3.45..20.55; these are current construction measurements, not a new height rule. Rear geometry is authored in native coordinates before1.5 offset construction, so scaling a primitive does not scale its stroke.

Outline must show only visible layer edges, without hidden rear strokes crossing the front. Keep the drawing transparent: do not mask occlusion with a hardcoded white or surface-colored patch. Filled needs the union of the visible forms with deliberate transparent counters or a clear layer seam; overlapping evenodd paths must not accidentally cancel the body. The old straight divider is replaced by the front layer's actual curved upper boundary. The current Filled counter is a native1.5-wide curved strip following that boundary, with.75 end caps and endpoint X insets1.8/1.5 from the layer junctions to retain solid bridges. The Outline union inset uses.75-radius connectors at concave layer intersections. Validate native contour matching there as well as on smooth curves. Verify the exterior styles against each other and inspect light/dark actual-size output.

### Figma design workspace — original editable studies

**Current owner priority:** finish Camera and Folder prototypes in the local Lab first, then move the completed design work to Figma. Do not spend further time arranging or editing the Figma snapshot while these two prototypes remain rejected. The existing file is retained as a historical draft, not the active review surface or an accepted design.

The owner asked to use Figma for direct shape design. The working [Shape & Icon Studies file](https://www.figma.com/design/5H3BjvQHvoTlkqp73YNx17?node-id=4-26) contains original editable24×24 Square, Camera and Folder masters in Outline/Filled, with linked enlarged comparison instances. The accepted Balanced Square is a locked reference. Camera housing and Folder tab remain separately editable draft parts. Visible Outline strokes stay at1.5 native units; an enlarged preview is not a new stroke specification.

Use Figma to explore and review the design, with the accepted Square as a family reference and the part-by-part judgment above. Do not copy external artwork or force every detail into the same curve. This file is an explicit snapshot of the Core study, not automatic two-way synchronization. After an owner-approved edit, translate the accepted vector construction back into Core, record its rationale and review status, verify it, then promote through the pinned Svelte adapter to the standalone Lab. Core remains the source for shipped artwork. Lab remains the check for actual16/20/24/48px rendering, native margins, weights, style contours and application behavior. A Figma review does not bypass those checks or approve unrelated production icons.

The initial canvas uses comparison board `4:26` and24px master area `4:5`. Original SVG paths were imported as native vectors; Outline Camera/Folder semantic tops are separate from body and interior parts. Filled counters remain transparent compound paths. Keep linked comparison instances and native dimensions intact when editing. Current Camera/Folder drawings still require owner visual review.

### Shared prototype grammar: Square, Camera and Folder

Square remains the exact owner-accepted Balanced whole-contour base. Camera and Folder are **semantic object drawings**, not stretched copies of that square. The earlier anisotropic-superellipse bodies, additive bumps and subsequent low-roof adjustments are rejected study history. Do not use those silhouettes as the starting point again.

Camera currently starts from the project's own original silhouette at Core `310b780`, with selective main-body corner transitions. Its dimensions are a draft, not a height constraint. Folder now follows the owner's cut-Square direction above. Retain meaningful straight sections, housing, tabs and clear detail placement where appropriate; do not force the same mathematical contour onto every semantic part. The controls may compare curve character across subjects while semantic subparts stay stable within each current design. All construction is authored independently from our own sources.

Camera's current experimental main-body corner is a quintic with collinear endpoint controls, zero curvature at adjoining straight sections and coefficient `k = .26 + .035 × (exponent − 2)`; Balanced3.2 uses.302. Its original housing stays stable within this curve-only control. These are current draft choices, not permanent height/proportion constraints or a universal corner recipe.

Folder retains **our own Square's accepted lower half**, with its native curve shape unchanged. Build the upper front panel and smaller rear squircle as separate meaningful forms, resolve which edges remain visible, then construct the combined transparent drawing. The earlier cut-only levels and−1.9 Y shift are historical draft values. They do not constrain the new front/rear proportions or optical placement. A uniform Y recenter is allowed; the accepted lower shape must not be squashed or refit.

Use1.5 native stroke and primary visiblex2..22 margins. Camera is built Outline-first with a native.75 outward normal offset for Filled. Folder's visible combined exterior is built from our own forms, with its Outline body.75 inward along the native normal and visible front-layer edges resolved separately. Preserve transparent compound-path counters and finite, non-cusping joins across profiles2..5. Retained Square cubic intervals stay aligned to its original sampling grid. Camera remains unchanged in this Folder-only revision; its lens/indicator keep the currently recorded study construction.

The previous cut-only Folder placed its divider at nativey10.3 with a1.5-high inset rounded Filled slot. That is a historical draft measurement; the overlapping-form model now determines the visible front layer boundary and Filled seam. It is intentionally inset rather than subtracting the entire full-width Outline divider and splitting the body. Current cut heights, divider position and slot span describe the draft; update them deliberately when the design changes rather than treating historical values as immutable. Tests verify retained Square lower geometry, stroke/contour correspondence, counter clearance, finite joins and the agreed primary margins. They must not lock the rejected Folder's height or every old control point.

The Lab compares all three subjects at the same body-curve setting, style and scale, fixed1.5 stroke and actual16/20/24/48px output. The public Core study contract remains `prototypeStudy(subject, exponent)`, returning native Outline/Filled path data. These subjects stay outside production icon counts, review records and six-icon batching. Existing production SVGs and morphs remain untouched. Square and the current Folder lower portion are accepted in their scoped reference settings; Camera and the complete Folder remain drafts pending visual review. Figma receives completed reviewed work later, rather than driving this unfinished prototype iteration.

## Camera original-squircle trial — 2026-10-28

**Historical production trial:** this earlier Camera-only draft remains separate from the active1.5 three-subject study. The latest prototype work restores the earlier own-source silhouette as described above; it does not change this production SVG.

Camera is the first scoped artwork redesign. Its semantic structure remains a horizontal camera with a low raised housing, circular lens and indicator. The independently authored body uses a progressive corner profile: curvature starts at zero beside a straight side, increases through the turn and returns to zero at the next side. The lens remains circular because it describes an optical aperture. The shallow housing is integrated into the body rather than adding a generic enclosing frame.

The Camera-only construction is recorded in its source metadata and [authoring reference](tools/camera-design.ts). It uses quintic profiles, with cubic Hermite source fitting and an analytical outward normal offset for the Filled exterior. Curve-fitting position error must stay below0.0001 native units; sampled joins preserve tangent/zero-curvature contact with straight sections. The Regular visible bounds are x2..22/y3.625..20.375, centered at12,12. The Filled lens is an intentional solid-style counter at the shared lens centerline radius, not a requirement to fill or copy every Outline interior.

Both revised Camera styles are **drafts awaiting owner visual review**. Other artwork and approval records remain unchanged. These profile proportions are an experiment for this subject, not a newly approved universal recipe. Review the real Lab and actual16/20/24/48px output before extending the grammar to other subjects. Camera has no current morph endpoint; no animation change is part of this trial.

## Current static approval — 2026-10-27

The owner explicitly approved **all current static icons**, including every available style and requested Square/Circle drawing. This covers51 authoring families and121 separately exported static icons after the frame split. Preserve every existing SVG path and prior review history while recording the approval. The Camera-only trial above reopens its two style reviews. Current `metadata.review` is authoritative; earlier draft statements in historical construction notes are superseded. New or changed artwork must reopen the affected review. Static approval does not approve any morph or motion.

## Start here

1. Read this playbook and the applicable `AGENTS.md` and `CONTRIBUTING.md` files.
2. Inspect the user's request and the working state of the three source repositories and standalone local app. Preserve unrelated work.
3. Identify the icon family, required styles/frames, current source geometry and approval status.
4. Use the workflow in section 4, the verification criteria in section 5 and the test plan in section 6.
5. Deliver a working, checked Lab result and the evidence in section 7. Do not stop at a plan when implementation is requested.

A named icon request authorizes its necessary implementation and preview. Choose routine details within the established rules. Ask when an unresolved choice would materially change identity, scope, geometry, styles, frames or an accepted result; continue independent work while waiting. A brief or checklist records decisions and is not a mandatory approval checkpoint.

Apply current user instructions within the applicable higher-priority instructions. This document records the current icon contract; older dated trials in supporting documents are history, not alternative specifications. If the request, this guide and the source disagree materially, identify the conflict and resolve it before making dependent changes. Do not silently restore an older design.

### Quick task map

| Request                                           | Start with                                                                 | Required result                                                                                  |
| ------------------------------------------------- | -------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------ |
| New icon or ordinary add-icons batch              | Semantic brief and our own shape grammar, Outline source, Filled treatment | Original SVG/metadata, requested variants, packed exports and Lab preview                        |
| Size, rounding, spacing or orientation correction | Existing source and acceptance record                                      | Revised native geometry; corresponding styles remain aligned; affected checks updated            |
| Frame or style extension                          | Shared glyph, frame geometry and style semantics                           | Separate named icons/components for each requested frame, with consistent styles and checks      |
| Adapter/API change                                | Core contract and generator                                                | Deterministic outputs, direct-import isolation, compatibility and consumer checks                |
| Lab-only change                                   | Current packed Lab dependency                                              | Correct controls, measurements, accessible interaction and responsive preview                    |
| Morph                                             | [Core MORPH.md](MORPH.md)                                                  | Follow that canonical motion playbook in addition to these static rules                          |
| Documentation-only change                         | Current rules, source and package scripts                                  | Clear current instructions, valid links/commands and consistent entry points; no artwork changes |

## 1. Goal

Create an independently designed squircle icon family with a recognizable identity of its own, readable at actual UI sizes. A completed implementation must:

- Express our own coordinated silhouette, corner transitions, proportions and negative-space rhythm; rounded caps or a larger circular corner radius alone do not establish the identity.
- Keep the correct geometric relationship between Outline, Bold, Filled and frames; matching bounding boxes alone is insufficient.
- Preserve accepted artwork and motion outside the requested revision.
- Keep core framework-independent, static imports lightweight and morphs opt-in.
- Reach the real Lab through traceable core → Svelte → local Lab promotion, preserving every draft and the separate public package pin.
- Include reproducible checks and visual evidence, with implementation completion separate from owner approval.

In this project's intended squircle language, the transition from a straighter side into a corner develops progressively, rather than relying only on a constant-radius circular fillet. This describes the intended main-body language where it fits, not a mandate for every small corner or semantic subpart, and not a claim that the current collection already meets it. Keep meaningful circles, straight segments, open forms and distinguishing features where the icon's meaning requires them. A shared language does not mean forcing every subject into the same outline.

A request is complete when its intended working result is delivered and verified. **Visual approval is a separate owner decision.** Do not mark a drawing approved merely because implementation or tests are complete.

## 2. Rules and ownership

### 2.1 Edit the correct layer

| Location         | Owns                                                                                                       | Do not put here                                                     |
| ---------------- | ---------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------- |
| `repos/core`     | Original SVGs, construction metadata, frame sources, shared types and framework-independent morph geometry | Framework components, Lab-only geometry corrections                 |
| `repos/svelte`   | Generator, presentation props, accessibility, packed consumers and component tests                         | Hand-edited generated icon paths or independent replacement artwork |
| `repos/lab`      | Independent private local app: review workbench, measurements, controls and morph previews                 | Copied artwork or imports from Homepage                             |
| `repos/homepage` | Public website and gallery, using the published adapter                                                    | Review routes, draft packages or development Lab dependencies       |

The root `icons/`, `packages/` and `apps/` folders are historical snapshots. **Do not edit them for active icon work.** Original SVGs and metadata are authoritative artwork sources; generated catalogs and components are outputs.

Inspect `git status --short` in each source repository before edits; the local app has no Git repository. Preserve unrelated changes and review records. Do not reset, discard or overwrite another chat's work to make a sync command pass. When sync requires a clean source, use an exact committed source snapshot and retain its provenance.

### 2.2 Scope and batching

An ordinary request to add icons means **six total**. Named icons occupy places in that six; choose the remainder automatically. Do not ask the owner to fill the remaining places. **A new identity defaults to None only. Add Square/Circle variants only when the owner explicitly requests frames; another family having frames is not authorization to add them everywhere.**

Explicit family extensions and construction revisions follow their requested scope. Adding frames does not create another six-icon batch. The Plus/Minus/X family revision adds Minus to the existing symbols; it does not authorize unrelated additions. Outline/Filled are styles of one icon. Each requested Square/Circle drawing is a separate named static icon, exported component and sidebar entry. A frame extension still does not trigger an unrelated six-icon batch.

### 2.3 Preserve contracts

- **Develop the design independently.** Define the subject, action and essential features first, then construct our own silhouette, spacing and curves. External collections are not construction templates or a source of design ideas to transplant. Replacing points, changing a radius or mirroring someone else's drawing does not make it our design.

- **Reuse before adding an identity.** When the drawing already exists as a named icon or style and only the action name differs, reuse that existing icon. Record the semantic mapping and add discovery tags; do not duplicate SVG geometry, generated components or alias exports. New Tab = Plus Square is the current example. Do not invent a duplicate identity merely to fill a six-action batch.
- Author original geometry and keep metadata authorship accurate.
- Use stable kebab-case icon names and stable `data-part` names. Preserve existing public names unless a rename is requested.
- Keep direct Svelte imports independent of barrels, catalogs, unrelated icon geometry and animation runtime.
- Keep the published public package and the development Lab package separate. A Lab update must retain draft icons and must not silently replace the public dependency.
- New/revised drawings remain `draft` until explicitly accepted. Preserve approval history and reopen the affected review when construction changes.
- Do not publish a package or deploy a website unless requested. A local Lab preview is the normal review deliverable.

### 2.4 Standalone local review app

`repos/lab` is a private local app, not a new Git/GitHub repository. It owns its package manifest, lockfile, packed review artifact, catalog generation, dev server, production build and tests. Its runtime, check and build must work without Homepage or sibling source checkouts. Only an explicit package-sync operation needs the Svelte source checkout.

The canonical icon rules are this file in Core. Local-app agents read `../core/ICON_RULES.md`; no copied rule body is maintained in the app. The root workspace file is an entry link. Homepage must have no review routes, preview helpers, development icon dependency, review-specific tests or sync tools. Its public package pin remains independent.

The icon-production agent owns static artwork and the shared icon concept. Hand static endpoint changes and their construction contract to the separate icon morph owner for animation work; a static design request does not transfer motion implementation into this role.

Core → Svelte → local Lab is the icon-development path. Updating the published website is a separate task, using a released package.

## 3. Design contract

Use the following current rules to design the source. Family exceptions are intentional; do not apply one family's Filled construction or margin rule to every other icon.

### 3.1 Artboard, weight and shape

For the existing collection, use a native **24 × 24** artboard, centered at **12,12**. The new-design study uses the scoped1.5 base above; the following weight palette remains the existing collection baseline. Native SVG units correspond to pixels when rendered at 24px.

| Weight              | Stroke width |
| ------------------- | -----------: |
| Thin                |         1.25 |
| Regular / default   |         1.75 |
| Bold                |         2.50 |
| Lab adjustment step |         0.25 |

- Use round line caps and round line joins. A round cap's radius is half its stroke width.
- Keep artwork monochrome and inherit `currentColor`.
- Preserve meaningful straight edges, circles, openings and proportions. Do not curve interior details just to make them softer.
- Avoid doubled shared edges, uneven joins and accidental dark intersections. Union overlapping Filled contours where necessary.
- Inspect actual 16, 20, 24 and 48px output on both light and dark surfaces.

**Approved circular-corner baseline:** the existing comparable full-size object corners and L elbows use tangent centerline arcs of radius3.25 at Regular1.75, with round cap radius0.875. Maximize/Minimize Filled follows Bold2.50, with cap radius1.25 and elbow outer/inner radii4.5/2. Preserve these exact sources when verifying or maintaining the approved baseline. A sharp H/V centerline with only a round stroke join does not reproduce that baseline.

These circular-arc values are not a universal squircle construction rule for future redesigns. The earlier instruction to apply radius3.25 automatically to every new comparable corner is superseded by the current conceptual direction. A later artwork task must first establish our independently designed silhouette and progressive corner profile, with its own rationale and review evidence. Do not guess a numeric replacement or silently refit the whole collection now.

Camera/Folder fitted bodies, small semantic details and the current Square frame exterior radius6 remain approved baseline references. Preserve their approved baseline outside an explicitly requested revision; Camera is now the first scoped trial. Future profiles must respect the subject's meaning and scale; neither a single fixed radius nor one universal outline should be imposed on every feature.

### 3.2 Margins and optical size

Measure the **visible edge**, including stroke and rounded caps, rather than only the centerline bounds.

- Use **2px on the primary opposing edge pair** when an icon is fitted to that pair.
- Camera and Folder use left/right, retaining their horizontal proportions. Another object may use top/bottom. The remaining pair may have larger margins.
- Naturally filled objects use their own silhouette; do not add an unnecessary box.
- Square/Circle frame exteriors have 2px on all four sides.
- **Where frames are explicitly supported, None is deliberately larger than Square/Circle.** Author larger native standalone geometry while preserving the existing compact framed glyphs. Fit the primary visible extent to20px at the family reference weight: Regular1.75 for directional/natural geometry and Bold2.50 for Bold-style Filled marks. The latter therefore has19.25px Regular Outline extent (2.375px primary margins). Arrow diagonals retain the same physical axial size, rather than being independently fitted to both artboard axes.
- Keep opposite margins balanced and preserve the native source proportions.
- Bake an accepted orientation or proportion change into the source when requested; Lab X/Y should return to 100/100 and rotation to 0 for that new native baseline.

Directional geometry must retain the same physical construction. Rotate and, where needed, recenter it. Do not independently scale diagonal variants to touch the artboard edges.

### 3.3 Styles

#### Outline

Outline uses the original centerlines, configurable stroke width, and Regular 1.75 by default.

#### Bold

Plus, Minus and X have an explicit **Bold** style in Lab. It uses the same centerlines at fixed 2.50 and is unboxed. The Svelte `style="bold"` rendering uses that fixed weight; a supplied frame is ignored for this style.

#### Filled

Filled is authored fill-only geometry. It is not the result of indiscriminately filling every Outline path.

| Family                                 | Current Filled treatment                                               |
| -------------------------------------- | ---------------------------------------------------------------------- |
| Camera, Folder and other solid objects | Natural solid silhouette with intentional counters and openings        |
| Menu (no frame) and Search             | Unboxed Bold 2.50 expansion of the shared centerlines                  |
| Menu, Square/Circle                    | Solid frame with its compact Bold 2.50 glyph silhouette cut out        |
| Plus, Minus and X, unframed            | Unboxed Bold 2.50, matching the explicit Bold style                    |
| Plus, Minus and X, Square/Circle       | Solid frame with the exact Regular 1.75 symbol cut out                 |
| Arrow and Chevron, no frame            | Solid rounded triangular head; preserve the shared source construction |
| Arrow and Chevron, Square/Circle       | Solid frame with its compact Filled glyph silhouette cut out           |
| Check, no frame                        | Unboxed Bold 2.50 expansion of the shared check centerline             |
| Check, Square/Circle                   | Solid frame with its compact Bold silhouette cut out                   |

For natural dual-style objects, match the Filled exterior to the visible Regular Outline exterior. For Menu/Search, Check, alignment bars and unframed math symbols, compare Filled to **Bold 2.50**, not Regular. For boxed math marks, compare the hole to the corresponding Regular mark. Framed Menu, Check and alignment bars use the compact framed glyph expanded at Bold as their cutouts. Maximize and Minimize are None-only. Directional families likewise use their compact framed solid-head geometry. Compare within the selected frame variant; the larger None silhouette is a separate source.

Keep the compact glyph identical between Square and Circle. None uses its separately authored larger geometry. Never enlarge a Filled path by scaling its stroke, and never simulate this size distinction with Lab-only transforms. This owner correction supersedes older same-size-None/frame instructions in historical metadata and supporting notes.

### 3.4 Frame construction

**Frames are separate static icons and components.** Export `Plus`, `PlusSquare` and `PlusCircle` as independent geometry, using paths `plus`, `plus-square` and `plus-circle`. Do not combine these drawings inside one component or expose a static `frame` prop. Each named drawing has its own Lab sidebar entry; Outline/Filled remain styles of that drawing. Add framed icons only when the owner requests them. External Link, Maximize and Minimize have no added framed icons. New Tab reuses `PlusSquare`, with no duplicate New Tab export.

Core may keep related artwork nested under its authoring family for source ownership and pure morph builders. The adapter flattens the current51 authoring families and70 framed drawings into121 separate static icons. Each generated component includes only its selected drawing, with no hidden sibling-frame geometry. Catalog `baseIcon` and fixed `frame` fields describe provenance; they are not runtime switching props. Morph pair controls may select corresponding explicit static endpoint components without restoring a combined static component.

The following measurements describe the current approved baseline, not the unestablished future squircle profile:

| Measurement                  | Square                                   | Circle                     |
| ---------------------------- | ---------------------------------------- | -------------------------- |
| Filled exterior              | Bounds 2..22, corner radius6             | Center 12,12, radius 10    |
| Outline centerline           | Bounds 2.875..21.125, corner radius5.125 | Center 12,12, radius 9.125 |
| Default frame stroke         | 1.75                                     | 1.75                       |
| Default visible outer margin | 2 on all sides                           | 2 on all sides             |

The Square stays upright when a directional glyph rotates. Its current radius6 exterior / radius5.125 Outline centerline is the owner-approved rounder construction, replacing the previous radius4/3.125 enclosing frame. Change only the enclosing contour: glyph paths, cutouts, positions and local radii remain unchanged unless separately requested. Cutouts are transparent negative space; preserve exact unions and correct fill rules.

Check glyph-to-frame clearance at Regular and Bold, especially near Circle borders and diagonal endpoints. The outer 2px margin is the default Regular measurement; changing the Outline stroke changes its visible exterior normally.

### 3.5 Current family geometry

#### Arrow

Eight directions × three frame choices = **24 variants**, each with Outline/Filled. None and framed versions have distinct native size references:

| Reference           | Shaft | Head half-span | Visible axial length |   Cardinal primary margin |
| ------------------- | ----: | -------------: | -------------------: | ------------------------: |
| None                | 18.25 |        6.84375 |                   20 |                         2 |
| Square/Circle glyph | 12.25 |        4.59375 |                   14 | 5 before adding the frame |

Use Regular1.75 and identical arm proportions within each size reference. Rotate one reference about12,12 for all eight directions; do not scale diagonals independently. None diagonal visible X/Y margins are4.67265062; the smaller framed glyph remains unchanged. Rebuild Filled at fixed radius0.875, analytically uniting the shaft and solid rounded head.

#### Single and Double Chevron

Single and Double Chevron each have four cardinal directions only, with no diagonal exports. Four Single + four Double identities × three frames = **24 variants**, each with Outline/Filled. Double names remain `chevrons-up/down/left/right`.

- Compact framed Single Up vertices remain `(6.5,14.75) → (12,9.25) → (17.5,14.75)`. None uses local vertices `(-9.125,4.5625) → (0,-4.5625) → (9.125,4.5625)` before centering/rotation, giving20px visible primary width at Regular1.75.
- Compact framed Double keeps local vertices `(-4,2) → (0,-2) → (4,2)` with centers−2.875/+2.875. Its visible size is9.75×11.50 for Up/Down.
- Larger None Double uses local vertices `(-8.25,4.125) → (0,-4.125) → (8.25,4.125)` with centers−5/+5 along its axis. Its visible primary extent is20px, and the expanded Filled heads still touch exactly at the center with zero gap or overlap. This separately solved construction preserves contact; a uniform scale of the previous Filled path would be wrong.
- Keep stroke/cap radius fixed at Regular1.75/0.875 in every source. Square/Circle glyph geometry stays unchanged; rotate the appropriate None or compact reference rigidly for direction changes.

#### Opposed Chevron and Chevron Line

These six identities are `chevron-up-down`, `chevron-left-right` and `chevron-line-up/down/left/right`. Up–Down combines two outward-facing heads; Left–Right is its quarter-turn. Line adds a separate stop line ahead of the V tip.

Compact framed Up–Down vertices remain `(8,10.5) → (12,6.5) → (16,10.5)` and `(16,13.5) → (12,17.5) → (8,13.5)`. Its None centerlines scale uniformly by73/44 about12,12, keeping Regular1.75 fixed and giving20px visible primary extent. Chevron Line keeps the existing V size but moves its stop line closer by balanced repositioning. Compact Line Up uses `(8,15.25) → (12,11.25) → (16,15.25)` with bar `(8,8.75) → (16,8.75)`, giving a2.5-unit centerline gap. None retains V half-width9.125, with bar y5.9375, tip y8.9375 and base y18.0625, giving a3-unit gap and20×13.875px Regular visible bounds. Both references remain centered; other directions are rigid rotations.

Filled closes and expands each triangle at radius0.875 and adds a matching fixed-radius capsule where needed. Opposed None gaps grow with its centerline proportions; its compact framed gaps remain1.25px at Regular and0.5px at Bold. Line None keeps1.25px Regular /0.5px Bold separation; compact Line keeps0.75px Regular separation and intentionally reaches tangency at Bold2.50, without overlap. Frame Filled uses the unchanged compact silhouette as its cutout. The current static drawings and framed icons are owner-approved; future geometry revisions reopen only their affected review.

#### Plus / Minus / X

These retain three styles: Outline / Bold / Filled. None Filled equals unboxed Bold2.50. Larger None centerlines use extent8.75 about12,12: Plus `M3.25 12 H20.75 M12 3.25 V20.75`, Minus the horizontal segment, and X the two diagonals between3.25 and20.75. None Bold/Filled visible bounds are2..22; Regular Outline primary margins are2.375.

Square/Circle keep their original compact centerline extent4.5: Plus `M7.5 12 H16.5 M12 7.5 V16.5`, Minus the horizontal segment, and X the two diagonals between7.5 and16.5. Framed Filled uses the compact Regular1.75 cutout. Bold remains explicitly unboxed and ignores frame selection. Do not substitute the larger None mark into a frame.

New Tab is a semantic use of the existing Plus Square variant, in either supported style. Keep `new-tab` and `newtab` as discovery tags on Plus and its Square metadata. Do not create another `new-tab` identity, source SVG, component, or alias export for the same drawing. New Window remains the separate overlapping-window identity described below.

#### Check

Check supports Outline/Filled and all three frame choices. Larger None vertices are `(3.25,12.67307692) → (8.63461539,18.05769231) → (20.75,5.94230769)`. Compact Square/Circle vertices remain `(7,12.38461538) → (10.07692308,15.46153846) → (17,8.53846154)`. Both preserve the original4:9 arm ratio and45-degree slopes.

Regular Outline is1.75. None Filled is the exact larger Bold2.50 expansion; framed Filled cuts out the compact Bold mark. Use one analytical union contour with radius1.25 caps/outer join and an intersected inner offset corner, never overlapping evenodd capsules. None Filled has20px primary width; compact frame geometry stays unchanged. The earlier standalone boxed Filled is superseded. Preserve prior approval history; the owner has approved this current static drawing.

#### Corner and entry/exit controls

`corner-up-right`, `log-in` and `log-out` retain Outline/Filled and all frames. Their compact framed references remain unchanged:

- Corner uses `M8 16.75 V13.75 A3 3 0 0 1 11 10.75 H16`, with head `(12.5,7.25) → (16,10.75) → (12.5,14.25)`. None centerlines uniformly scale by18.25/9.5 about12,12, keeping1.75 stroke and rebuilding Filled with0.875 expansion. Its visible top/bottom are2..22; left/right are3.44078947..20.55921053.
- Entry/Exit compact rounded C doors occupy y7.5..16.5 with radius1.5. Entry bounds x12.5..16.5 open left; Exit mirrors the door to x7.5..11.5 and opens right. Both arrows point right. Entry shaft x7.5..12.5 has head base x9.5; Exit shaft x11.5..16.5 has head base x13.5; both heads use y9/15. None scales centerlines by18.25/9 about12,12 and rebuilds the natural Filled doorway/solid-head union at0.875, yielding Regular visible bounds2..22. Never reverse the exit arrow merely because its doorway is mirrored.

#### Alignment

Alignment uses unboxed Bold2.50 Filled and retains its explicitly requested Square/Circle variants with compact Bold cutouts. Every None reference has20px primary extent at Bold and19.25px at Regular.

- Alignment None rows are y3.25,9.08333333,14.91666667,20.75. Long bars span x3.25..20.75; short bars are11.66666667 units with their Left/Center/Right anchors preserved. Compact rows remain y7.5,10.5,13.5,16.5, with long9-unit bars x7.5..16.5 and short6-unit bars x7.5..13.5 / x9..15 / x10.5..16.5 respectively.

#### Maximize and Minimize

These are a related pair of natural four-corner marks with Outline/Filled and no enclosing Square/Circle variants. The approved baseline uses actual rounded elbows and a separate inward-facing Minimize drawing; these circular arcs do not define the future squircle grammar. Keep their centerline extrema3.25..20.75 and arm span5.46875.

- Maximize points each rounded L toward its artboard corner. Elbow centerline radius is3.25 with straight tangent lead-ins, not a sharp H/V turn. Regular Outline remains1.75 with round end caps.
- Minimize turns each Maximize L by180 degrees about that corner's local center: `(5.984375,5.984375)`, `(18.015625,5.984375)`, `(18.015625,18.015625)` and `(5.984375,18.015625)`. This changes the corner's direction while retaining placement, arm span, roundness and bounds; it is not a whole-icon rotation or a duplicate alias.
- Filled is an exact Bold2.50 stroked union: radius1.25 end caps and elbow outer/inner radii4.5/2. Use tangent circular arcs and one closed contour per corner, without overlapping evenodd seams. Bold/Filled visible bounds remain2..22; Regular Outline margins are2.375.
- Preserve prior Maximize review history; both current rounded static endpoints are owner-approved. For the named Maximize↔Minimize morph, follow [MORPH.md](MORPH.md), derive both static endpoints exactly and preserve the shared source weight/tangent construction; static implementation and motion approval remain separate.

#### More controls

Compact `more-horizontal/vertical` references remain three centers7.5/12/16.5 along their axis, Outline circle radius1 and natural Filled radius1.875. Larger None scales the centers/circle centerlines by73/44: centers12±7.46590909, Outline radius1.65909091 and Filled radius2.53409091. Stroke stays1.75; Filled is a freshly rebuilt visible exterior, not Bold. None primary bounds are2..22 and perpendicular visible size5.06818182. Frames retain their exact compact three-dot cutouts.

#### Copy and New Window

Copy places its foreground sheet bottom-left and background sheet top-right, by a baked horizontal reflection about x12. Every endpoint/control point maps x→24−x, elliptical-axis rotations negate and arc sweep flags reverse. Preserve original object roundness, rear-junction breaks, exposed parallel-border spacing and combined Regular visible bounds2..22. Filled is the natural silhouette with a solid foreground sheet.

`new-window` preserves both former Copy SVG files byte-for-byte, with foreground bottom-right and background top-left. Neither identity has additional Square/Circle variants, so this None-versus-frame enlargement does not resize them. New Window does not inherit Copy approval; revised Copy keeps previous approval in history. Both current static drawings were included in the owner's collection-wide approval.

#### External Link

External Link is explicitly None-only; do not add enclosing Square/Circle variants.

- External Link uses a natural open window with centerline radius5.125, Filled outer/inner radii6/4.25 and visible bounds2..22. Quarter-circle centers are `(8,8)`, `(8,16)` and `(16,16)`; the top arm ends at `(8,2.875)` and right arm at `(21.125,16)`. Keep the diagonal shaft and arrowhead geometry unchanged when revising the window's corner rounding. Filled unites the same natural window expansion and solid-head arrow; do not add a second box.

#### Menu and Trash

Menu larger None centerlines span x3.25..20.75 at y5,12,19. Filled is exact Bold2.50, with visible width20 and height16.5. Compact Square/Circle bars stay x7..17 at y8,12,16; their Filled cutouts use that compact Bold silhouette. Never reuse the enlarged None paths inside a frame.

Trash has no new enclosing frames and keeps its baked105/95 proportions, body, lid and handle. Short internal slots remain x9.9/14.1, y11.1..15.75 at1.75 weight with matching radius0.875 Filled capsules. These earlier slot revisions are unchanged by the None/frame sizing correction.

### 3.6 Authored morphs

Morphs are deliberately designed pairs, not arbitrary icon interpolation. Preserve accepted motion independently from static drawing approval.

- **Sun ↔ Moon:** preferred reference for continuous shape change and smooth reversal. Derive current endpoints from the source icons, including the 3px Sun rays and Moon's baked orientation.
- **Plus ↔ X:** merge into one horizontal line at progress 0.5 and immediately open into X. No midpoint hold or easing to a stop. Preserve matching nonzero angular velocity and continuous acceleration through the merge. Keep the approved 0.4× shared spring pace.
- **Menu ↔ X:** separately authored topology bridge; it remains a proposal until explicitly approved.
- Retarget from the current position and velocity; do not restart the SVG from an endpoint.
- Respect reduced motion. Keep morph imports separate from static icon imports.
- Morph endpoint builders must resolve the exact selected frame source. None uses its newly enlarged native geometry; Square/Circle keep their compact references. Regenerate each frame’s endpoint/intermediate geometry and compare packed endpoints against the corresponding static export. Do not feed enlarged None paths into every frame or change approved timing to hide a mismatch.

### 3.7 Source SVG and metadata contract

The current core parser supports `svg`, named `g` groups, `path` and `circle`. Convert other drawing primitives to supported paths rather than exporting an arbitrary editor document. Use the existing validator; do not bypass it to import unsupported artwork.

- The root namespace is `http://www.w3.org/2000/svg` and `viewBox` is exactly `0 0 24 24`.
- Outline uses root `fill="none"`, `stroke="currentColor"`, `stroke-width="1.75"`, round caps and joins, with no fill rule.
- Filled uses root `fill="currentColor"`, `stroke="none"` and `fill-rule="evenodd"`, with no stroke width.
- Put artwork under uniquely named groups such as `data-part="body"`, `lens` or `lid`. Paths contain finite SVG geometry; circles use finite `cx`, `cy` and positive `r`.
- Source SVGs do not contain size props, transforms, CSS, IDs, scripts, external references, XML declarations or editor metadata. Bake native transforms into geometry. The adapter owns rendered size and accessible attributes.
- Bold is rendered from the shared Outline centerlines at fixed 2.50; there is no separate `icons/bold/` source directory in the current pipeline. Its advertised availability comes from metadata.
- Filled is fixed authored geometry except the existing Folder divider, whose bounded adjustable gap is derived from its source metadata. Do not make other Filled counters adjustable implicitly.

Illustrative source structure using the unframed Minus family:

```svg
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round">
  <g data-part="body"><path d="M3.25 12 H20.75"/></g>
</svg>
```

Its unframed Filled treatment is the same centerline expanded at Bold 2.50:

```svg
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" stroke="none" fill-rule="evenodd">
  <g data-part="body"><path d="M3.25 10.75 H20.75 A1.25 1.25 0 0 1 20.75 13.25 H3.25 A1.25 1.25 0 0 1 3.25 10.75 Z"/></g>
</svg>
```

The adjacent JSON file must describe the actual drawing and design decision, not copied approval claims. For example:

```json
{
  "name": "minus",
  "description": "A rounded minus symbol.",
  "tags": ["minus", "remove", "math"],
  "authorship": "Original geometry constructed for this project; no third-party icon paths used.",
  "construction": "Centered at12,12. Larger None horizontal centerline spans3.25..20.75 and Filled matches Bold2.50. Square/Circle retain the compact7.5..16.5 reference with a Regular1.75 cutout. Native variants preserve fixed stroke weights without runtime scaling.",
  "filledTreatment": "bold-stroke",
  "supportsBold": true,
  "review": { "status": "draft" }
}
```

Use the real icon name and construction values. Keep the corresponding Filled and frame metadata synchronized. Omit optional treatments/capabilities that do not apply. Production geometry remains in the core SVG files; these examples explain the authoring contract.

## 4. Implementation workflow

Follow this sequence for implementation work. Each step produces a concrete result that the next step consumes. Apply only steps relevant to the request: a documentation-only change does not require authoring artwork, repinning packages or rebuilding Lab.

### Step 1 — Establish the baseline

- Read the current request, this guide and relevant source/test files. Paths beginning with `repos/` in this guide are relative to the workspace root. For artwork, also read the core construction references in section 9 and the repository's contribution instructions.
- Inspect the source repository states and local app, current dependency/provenance files and the affected icon's review metadata.
- View the current Lab and source at native proportions. Identify what is accepted, what is being revised and what remains outside scope.
- Use the configured package manager and runtime from repository manifests. Do not update unrelated dependencies to perform an icon change.

### Step 2 — Record the design decision

Before drawing, establish this small brief in the work notes or construction metadata:

```text
Identity / family:
Meaning, action and essential distinguishing features:
Requested change and preserved references:
Our independently developed silhouette and corner/negative-space decisions:
Required styles and frames:
Native center, primary margin pair and intended visible bounds:
Filled treatment and its comparison reference:
Shared geometry, optical exception or direction mapping:
Affected exports, Lab controls and morph endpoints:
Verification and test plan:
Review status:
```

Use the established family rules for routine choices. If a missing decision materially affects the result, ask the owner while progressing work that does not depend on the answer.

For a later redesign request, build the brief from the subject and our own design goals. Establish our shape grammar independently before proposing an artwork trial. Record why the proportions and corner progression belong to this family, without using another collection's geometry or stylistic solution as the target. Review a concrete trial before proposing a collection-wide migration. The Camera-only trial below is the first owner-requested application; it does not establish approval for other icons.

### Step 3 — Author in core

Use these source locations:

```text
repos/core/icons/<name>.svg
repos/core/icons/<name>.json
repos/core/icons/filled/<name>.svg
repos/core/icons/filled/<name>.json
repos/core/icons/frames/{square,circle}/<name>.svg
repos/core/icons/frames/{square,circle}/<name>.json
repos/core/icons/frames/{square,circle}/filled/<name>.svg
repos/core/icons/frames/{square,circle}/filled/<name>.json
```

1. Establish the Outline centerlines and native placement first.
2. Measure the visible Regular exterior, including caps and joins. Fit the correct primary margin pair without distorting the silhouette.
3. Derive the corresponding Filled exterior or cutout using the treatment in section 3.3. Construct exact unions at intersections; preserve counters and openings.
4. Add frames only when explicitly requested. For supported frame families, author the larger None glyph and preserve the compact shared Square/Circle glyphs as separate native variants. Keep Square upright, rebuild Filled at fixed family weight for each size, and verify compact Circle clearance.
5. Write/update metadata: name, description, tags, authorship, construction, parts and review status. Use `filledTreatment` consistently (`bold-stroke`, `boxed-cutout`, `solid-head` where applicable). The current math family uses `supportsBold: true`.
6. Update meaningful static source/geometry checks when behavior changes. If a static endpoint changes, give the morph owner the accepted source version and construction contract for endpoint updates and motion verification; preserve accepted timing and unrelated pairs.
7. Run core checks and commit the intended source changes before adapter synchronization.

### Step 4 — Generate and verify the adapter

From `repos/svelte`:

```sh
pnpm sync:core ../core
pnpm verify
```

Inspect the generated exports, catalog styles/frames and actual packed consumer. Update the generator or props for new capabilities; never patch generated SVG paths manually. Commit the adapter changes, generated files, packed core artifact, lockfile and provenance together.

### Step 5 — Promote to Lab

From `repos/lab`:

```sh
pnpm sync:svelte ../svelte
pnpm verify
```

Run the local app sync from `repos/lab`, not the website. It updates only the app’s packed review dependency. Homepage remains a separate published-package consumer. The local app has no Git repository and must not be published or pushed.

Open the standalone local app at its `/` route, select the affected icon and exercise its styles/frames. Confirm that it uses the new packed dependency; a successful build alone does not prove the open browser refreshed. Save visual evidence after checking the result.

### Step 6 — Close the loop

Perform the verification in section 5, finish the tests in section 6, update this guide if the owner changed a rule, and deliver the handoff in section 7. Do not stop after editing SVGs when the request requires a usable Lab result.

## 5. Verification — inspect the result

Verification checks whether the requested visual/product result is correct. Automated tests in section 6 support these checks; they do not replace visual inspection.

| Check                      | Method                                                                                          | Pass criterion                                                                                                    |
| -------------------------- | ----------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------- |
| Identity and silhouette    | Compare with our semantic brief and our own family at 16/20/24/48px                             | Recognizable, balanced and consistent; defining features survive at small sizes                                   |
| Original squircle language | For a later redesign, inspect our own side-to-corner progression, silhouette and negative space | A coherent original grammar; neither round caps alone nor similarity to an external collection establishes a pass |
| Native placement           | Measure at 24×24, X/Y 100/100, rotation 0, Regular 1.75                                         | Correct center and primary margin pair; opposite margins balanced                                                 |
| Visible bounds             | Include half-stroke, caps and joins in measurements                                             | Specified dimensions/margins match the current family; no hidden clipping                                         |
| Contour relationship       | Overlay/vector-sample or compare raster masks from actual packed exports                        | Objects match Regular exterior; Bold Filled matches 2.50; frame holes match their specified glyph                 |
| Frame consistency          | Toggle None/Square/Circle at equal scale and pose                                               | Square/Circle share the compact glyph; None is natively larger; fixed stroke and correct per-frame treatment      |
| Frame clearance            | Inspect nearest glyph/border points at Regular and Bold                                         | Positive clearance except a deliberately requested contact; default frame exterior has 2px margins                |
| Directional consistency    | Compare the source reference under rigid rotations                                              | Same physical construction; no independently enlarged diagonal directions; Square stays upright                   |
| Rounding and overlaps      | Inspect caps, joins, corners and intersections at enlarged and actual sizes                     | Smooth, intentional contours; no doubled edges, seams, accidental holes or unequal stroke weight                  |
| Lab behavior               | Select each named icon (including framed icons), switch style, edit/reset X/Y and rotation      | Correct supported options, preserved independent drafts, accurate measurements and native defaults                |
| Accessibility/layout       | Keyboard controls, accessible labels, desktop and mobile widths                                 | Usable controls, decorative SVGs hidden appropriately, meaningful icons named, no unintended page overflow        |
| Affected morphs            | Compare both packed endpoints and reverse during playback                                       | Correct source/style/frame endpoints; accepted motion, timing and continuity remain intact                        |

For numeric measurements, use tolerances appropriate to the existing geometry checks. Opposite-margin comparisons normally use about 0.001 native units. Allow a documented antialiasing fringe in raster checks, not a genuine shape mismatch. Existing contour tests use one raster pixel at 40× magnification as a fringe allowance; do not loosen thresholds simply to make a regression pass.

If X/Y or rotation hides a source mismatch, fix the source. Do not solve it with a style-specific preview transform. An accepted native-pose revision must open/reset at 100/100 and 0 in Lab.

## 6. Tests — reproduce the checks

Run commands from the repository indicated below. Read the current `package.json` scripts and contribution instructions before executing; this table explains their purpose and does not freeze dependency versions or test counts.

### Required suites

| Repository / command     | Establishes                                                                                                                              |
| ------------------------ | ---------------------------------------------------------------------------------------------------------------------------------------- |
| core: `pnpm verify`      | Formatting, safe/valid SVG and metadata, type checks, source/unit tests and rebuilt catalog/morph data                                   |
| Svelte: `pnpm verify`    | Provenance, deterministic generation, build/types, unit tests, bundle/import isolation, packed consumer, compatibility and browser tests |
| local app: `pnpm verify` | Formatting, pinned local-package provenance, catalog generation, types, unit tests, local production build and review behavior           |

For an artwork change delivered through Lab, complete the core → adapter → local app checks required by their contribution instructions. For a new capability, verify all supported variants, not just the selected screenshot. When Homepage itself changes, run its separate `pnpm verify` website suite; it is not a prerequisite for ordinary local Lab updates. Never claim a full suite passed if only selected tests ran.

### Baseline corner checks and future squircle verification

When maintaining the approved circular-corner baseline, verify actual source arcs, tangent continuity and the packed rendering. Its existing radius3.25 centerlines, Regular1.75 weight, radius0.875 caps and Maximize/Minimize Bold offsets remain covered by the [static corner regression](tests/unit/maximize-minimize-static.test.ts). Passing these checks proves baseline compatibility, not that an icon has the future squircle identity.

When an artwork redesign is later requested, add tests for the independently chosen profile: intended side-to-corner curvature progression, tangent continuity, finite/non-self-intersecting contours, visible bounds, weight and Outline/Filled relationships. State the intended continuity and numerical tolerances in that design's construction notes; do not invent universal values in advance. Inspect native sizes and the whole family visually as well. Neither automated geometry tests nor comparison with another library grants design approval.

### Choose tests by the change

| Change                             | Regression evidence to add or update                                                                                                                            |
| ---------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Outline/Filled geometry            | Packed contour comparison at native proportions and rotated poses, plus actual-size visual review                                                               |
| Frame construction                 | Exact shared glyph, correct default outer bounds, correct transparent cutout and clearance at relevant weights                                                  |
| Directional family                 | Rigid-rotation/equal-size contract and complete direction/frame coverage                                                                                        |
| Public props, exports or generator | Generation check, direct-import graph/bundle checks, packed consumer and compatibility suite                                                                    |
| Static endpoint used by a morph    | Regenerated endpoint data, packed endpoint comparison and affected reversal/intermediate-frame tests                                                            |
| Lab controls or measurements       | Named icon/style switching, resets, local edits, displayed spacing, keyboard access and affected viewport checks                                                |
| Documentation only                 | Verify current values against sources, resolve local links, check script names and Markdown formatting; no artwork/browser reruns unless implementation changed |

Useful focused commands, **after their required build/pack preparation**, include:

```sh
# repos/svelte
pnpm generate:check
pnpm test:pack
pnpm test:browser tests/browser/math-family.spec.ts
pnpm test:compat

# repos/lab
pnpm dependency:check
pnpm generate:check
pnpm check
pnpm build
pnpm test:browser tests/browser/lab.spec.ts
```

Svelte browser tests consume the fixture produced by `test:pack`; do not accidentally test an old fixture. Local-app browser tests must run against its newly built preview. Run the separate website suite only when the website was changed. Browser coverage uses Chromium, Firefox and WebKit. Use current repository scripts for consumer compatibility rather than assuming a local compiler proves all supported versions.

### When a check fails

1. Inspect the failing assertion and the actual source/artifact/browser state. Distinguish a geometry bug, stale output, wrong fixture/server, outdated expected behavior or an unrelated pre-existing failure.
2. Fix the responsible layer. Update an expected value only when the intended design changed and the new reference has been verified.
3. Regenerate and repack after source/generator changes. Refresh the real Lab dependency and browser when necessary.
4. Rerun the failed/affected checks. Broaden or repeat a full suite when subsequent changes create additional coverage needs; do not repeat unrelated checks without a reason.
5. If verification remains blocked, report the exact check, observed failure, work completed and remaining limitation. A saved log, successful command invocation or screenshot alone is not a pass.

If dev/build/test processes share output directories or a port, verify the server is serving the intended build. Use an isolated built preview when necessary. Preserve unrelated servers and working changes. Keep logs and screenshots in ignored `.artifacts/` directories; do not commit bulky reports as source.

## 7. Definition of done and handoff

Apply the items relevant to the request. For documentation-only work, validate the current contract, examples, links, commands, formatting and entry points; a new Lab build or screenshot is unnecessary. Before reporting icon implementation complete, confirm:

- [ ] All requested identities, styles and frames exist in the correct source layer.
- [ ] The design brief's geometry, treatment and preserved references are satisfied.
- [ ] Metadata, review status, parts and relevant documentation are current.
- [ ] Required generated artifacts and dependency provenance trace back to validated committed sources.
- [ ] Relevant automated checks have passed; any uncompleted check is stated accurately.
- [ ] The actual Lab shows the new packed result, with working controls and measurements.
- [ ] Actual-size and relevant viewport/pose comparisons have been inspected; visual evidence is saved.
- [ ] Unrelated icons, motions, working changes, Lab drafts and the public release pin are preserved.
- [ ] The final handoff states the concrete result, where to inspect it, validation performed and any material limitation.

Keep the handoff concise. Link the Lab and relevant source/document files; include the saved screenshot when reporting a visual UI change. Use wording such as **“Implemented and verified; awaiting owner visual review”** when appropriate. Do not convert `draft` to `approved` without explicit owner acceptance, and do not block delivery of a working preview merely to ask for routine confirmation.

## 8. Maintain this playbook

This file is an operating specification, not an append-only conversation log.

- Replace superseded rules in the current sections when the owner changes them. Keep historical detail in supporting decision records, clearly labeled as history.
- Update the affected source metadata, this guide and the relevant core design/boxed/margin reference together. A rule's impact on styles, frames, measurements, tests and morph endpoints must be explicit.
- Keep `AGENTS.md` and repository entry points short and linked to this guide. Do not duplicate numeric specifications there.
- Keep the morph implementation contract in the canonical core `MORPH.md`; this guide records only the static integration requirements.
- Recheck examples, file paths and package scripts when implementation changes. Do not record a temporary test count or localhost port as a permanent design rule.

## 9. Supporting references

The guide above is the current operational summary. Use these for source-level details and decision history:

- [Workspace agent entry point](../../AGENTS.md)
- [Core contribution instructions](CONTRIBUTING.md)
- [Core design and decision records](DESIGN_RULES.md)
- [Primary-margin details](ICON_MARGIN_RULES.md)
- [Box/cutout construction details](BOXED_ICON_RULES.md)
- [Batch and owner-review records](ICON_BATCHES.md)
- [Svelte contribution instructions](../svelte/CONTRIBUTING.md)
- [Local app contribution instructions](../lab/CONTRIBUTING.md)
- [Homepage contribution instructions](../homepage/CONTRIBUTING.md)
- [Canonical morph agent playbook](MORPH.md)
- [Local morph entry point](../lab/design/MORPH.md)

## Morph frame parity — owner correction, 2026-10-27

When a morph has frame variants, implement every supported frame for the whole
pair. Menu X, Plus X and Plus Minus support None/Square/Circle, with the same
selection at both ends and throughout Filled playback. No unboxed-to-box pairing
or silent fallback is allowed. Verify every variant using packed endpoints and
intermediate frames. See [MORPH.md](MORPH.md) for the canonical frame matrix and
source-derived weights. This supersedes earlier Menu X topology-bridge notes;
static icon construction, approval statuses and accepted motion timing stay intact.
