export type PartStyle = { transform: string; opacity?: number };
export type Pose = Record<string, PartStyle>;
export type MotionRecipe = {
  icon: string;
  kind: 'state' | 'pulse';
  initial: string;
  duration: number;
  easing: string;
  origins: Record<string, { x: number; y: number }>;
  states: Record<string, Pose>;
  tracks?: { part: string; keyframes: (PartStyle & { offset?: number })[] }[];
};
export type IconProps = {
  size?: number | string;
  color?: string;
  strokeWidth?: number;
  label?: string;
  class?: string;
};
export type FilledIconProps = Omit<IconProps, 'strokeWidth'>;
export type AnimatedProps = IconProps & { hover?: boolean; reducedMotion?: 'system' | 'always' };
