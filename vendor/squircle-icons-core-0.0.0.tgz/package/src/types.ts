export const STROKE_WEIGHTS = { thin: 1.25, regular: 1.7, bold: 2.25 } as const;

export type PartStyle = { transform: string; opacity?: number };
export type Pose = Record<string, PartStyle>;
export type MotionRecipe = {
  icon: string;
  kind: 'state' | 'pulse';
  initial: string;
  duration: number;
  easing: string;
  origins: Record<string, { x: number; y: number }>;
  states: Record<string, Pose>;
  tracks?: { part: string; keyframes: (PartStyle & { offset?: number })[] }[];
};
export type IconProps = {
  size?: number | string;
  color?: string;
  strokeWidth?: number;
  label?: string;
  class?: string;
};
// In filled artwork, strokeWidth controls designated negative-space cutouts.
export type FilledIconProps = IconProps;
export type AnimatedProps = IconProps & { hover?: boolean; reducedMotion?: 'system' | 'always' };
