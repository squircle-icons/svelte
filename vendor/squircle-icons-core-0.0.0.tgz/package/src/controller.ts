import type { MotionRecipe, Pose, PartStyle } from './types.js';

/** Browser operations happen only when the adapter explicitly constructs a controller. */
export function createMotionController(
  root: SVGSVGElement,
  recipe: MotionRecipe,
  initialState = recipe.initial,
) {
  let state = initialState;
  let reduced = false;
  let destroyed = false;
  const active = new Set<Animation>();
  const parts = new Map<string, SVGElement>();
  for (const name of Object.keys(recipe.origins)) {
    const element = root.querySelector<SVGElement>(`[data-part="${name}"]`);
    if (!element) throw new Error(`Missing motion part: ${name}`);
    parts.set(name, element);
  }
  const cancel = () => {
    for (const animation of active) {
      animation.onfinish = null;
      animation.cancel();
    }
    active.clear();
  };
  const apply = (pose: Pose) => {
    for (const [name, style] of Object.entries(pose)) {
      const element = parts.get(name)!;
      element.style.transform = style.transform;
      if (style.opacity !== undefined) element.style.opacity = String(style.opacity);
    }
  };
  const animate = (element: SVGElement, keyframes: Keyframe[], easing = recipe.easing) => {
    if (reduced || typeof element.animate !== 'function') return;
    const animation = element.animate(keyframes, {
      duration: recipe.duration,
      easing,
      iterations: 1,
      fill: 'none',
    });
    active.add(animation);
    animation.onfinish = () => {
      active.delete(animation);
      animation.onfinish = null;
      animation.cancel();
    };
  };
  const snap = () => {
    cancel();
    apply(recipe.states[state]);
  };
  apply(recipe.states[state]);
  return {
    setState(next: string, immediate = false) {
      if (destroyed) return;
      if (!recipe.states[next]) throw new Error(`Unknown state: ${next}`);
      if (next === state && !immediate) return;
      const from: Record<string, PartStyle> = {};
      for (const [name, element] of parts) {
        const computed = getComputedStyle(element);
        from[name] = { transform: computed.transform, opacity: Number(computed.opacity) };
      }
      state = next;
      snap();
      if (!immediate && !reduced)
        for (const [name, target] of Object.entries(recipe.states[state])) {
          animate(parts.get(name)!, [from[name], target]);
        }
    },
    play() {
      if (destroyed || recipe.kind !== 'pulse') return;
      state = recipe.initial;
      snap();
      if (!reduced)
        for (const track of recipe.tracks ?? []) animate(parts.get(track.part)!, track.keyframes);
    },
    reset(next = state) {
      if (destroyed) return;
      if (!recipe.states[next]) throw new Error(`Unknown state: ${next}`);
      state = next;
      snap();
    },
    setReduced(value: boolean) {
      if (!destroyed) {
        reduced = value;
        if (value) snap();
      }
    },
    destroy() {
      cancel();
      destroyed = true;
    },
  };
}
