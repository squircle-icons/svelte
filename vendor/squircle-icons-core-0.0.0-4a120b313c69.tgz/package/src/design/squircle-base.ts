/** Independent base-shape study. Not approved production icon/frame geometry. */
export const STUDY_STROKE = 1.5;
export const DEFAULT_ROUNDNESS = 3.2;
type Point = [number, number];
export type StudyShape = { outline: string; filled: string };
export type StudySubject = 'square' | 'camera' | 'folder';
const round = (n: number) => String(Number(n.toFixed(7)));
const xy = (p: Point) => p.map(round).join(' ');

/** A full-contour superellipse, with an inward normal offset for the stroke centerline. */
export function studyPoint(exponent: number, angle: number, inset = 0) {
  const c = Math.max(0, Math.cos(angle)),
    s = Math.max(0, Math.sin(angle));
  const f = c ** exponent + s ** exponent;
  const df = exponent * (-(c ** (exponent - 1)) * s + s ** (exponent - 1) * c);
  const r = 10 * f ** (-1 / exponent),
    dr = (-r * df) / (exponent * f);
  const g: Point = [c ** (exponent - 1), s ** (exponent - 1)];
  const dg: Point = [
    -(exponent - 1) * c ** (exponent - 2) * s,
    (exponent - 1) * s ** (exponent - 2) * c,
  ];
  const len = Math.hypot(...g),
    dot = (g[0] * dg[0] + g[1] * dg[1]) / len ** 2;
  const n: Point = [g[0] / len, g[1] / len];
  const dn: Point = [(dg[0] - g[0] * dot) / len, (dg[1] - g[1] * dot) / len];
  return {
    point: [r * c - inset * n[0], r * s - inset * n[1]] as Point,
    tangent: [dr * c - r * s - inset * dn[0], dr * s + r * c - inset * dn[1]] as Point,
  };
}
function contour(exponent: number, inset: number) {
  const rotate = ([x, y]: Point, q: number): Point =>
    q === 0
      ? [12 + x, 12 + y]
      : q === 1
        ? [12 - y, 12 + x]
        : q === 2
          ? [12 - x, 12 - y]
          : [12 + y, 12 - x];
  const segments = 32,
    step = Math.PI / 2 / segments;
  let d = `M${xy(rotate(studyPoint(exponent, 0, inset).point, 0))}`;
  for (let q = 0; q < 4; q++)
    for (let i = 0; i < segments; i++) {
      const a = studyPoint(exponent, i * step, inset),
        b = studyPoint(exponent, (i + 1) * step, inset);
      d += `C${xy(rotate([a.point[0] + (a.tangent[0] * step) / 3, a.point[1] + (a.tangent[1] * step) / 3], q))} ${xy(rotate([b.point[0] - (b.tangent[0] * step) / 3, b.point[1] - (b.tangent[1] * step) / 3], q))} ${xy(rotate(b.point, q))}`;
    }
  return d + 'Z';
}
export function squircleStudy(exponent = DEFAULT_ROUNDNESS): StudyShape {
  if (!Number.isFinite(exponent) || exponent < 2 || exponent > 5)
    throw new RangeError('Study exponent must be between2 and5');
  return { outline: contour(exponent, STUDY_STROKE / 2), filled: contour(exponent, 0) };
}

type Profile = Point[] & { fitSteps?: number };
const plus = (a: Point, b: Point): Point => [a[0] + b[0], a[1] + b[1]];
const times = (p: Point, k: number): Point => [p[0] * k, p[1] * k];
const minus = (a: Point, b: Point): Point => plus(a, times(b, -1));
function bezier(points: Profile, t: number): Point {
  let row = points;
  while (row.length > 1) row = row.slice(1).map((p, i) => plus(times(row[i], 1 - t), times(p, t)));
  return row[0];
}
const derivative = (points: Profile) =>
  points.slice(1).map((p, i) => times(minus(p, points[i]), points.length - 1));
function profilePoint(profile: Profile, t: number, offset: number) {
  const p = bezier(profile, t),
    d = bezier(derivative(profile), t),
    dd = profile.length > 2 ? bezier(derivative(derivative(profile)), t) : [0, 0];
  const speed = Math.hypot(...d),
    normal: Point = [d[1] / speed, -d[0] / speed];
  const dot = (d[0] * dd[0] + d[1] * dd[1]) / speed ** 2;
  const dn: Point = [dd[1] / speed - normal[0] * dot, -dd[0] / speed - normal[1] * dot];
  return { point: plus(p, times(normal, offset)), tangent: plus(d, times(dn, offset)) };
}
/** Only the large main-body corners receive the progressive family treatment. */
function bodyCorner(a: Point, b: Point, c: Point, exponent: number): Profile {
  const k = 0.26 + 0.035 * (exponent - 2);
  return [
    a,
    plus(a, times(minus(b, a), k)),
    plus(a, times(minus(b, a), 2 * k)),
    plus(c, times(minus(b, c), 2 * k)),
    plus(c, times(minus(b, c), k)),
    c,
  ];
}
function originalProfiles(subject: 'camera' | 'folder', exponent: number): Profile[] {
  if (subject === 'camera')
    return [
      bodyCorner([2.75, 9.38217258], [2.75, 6.63968611], [5.61748648, 6.63968611], exponent),
      [
        [5.61748648, 6.63968611],
        [8.2758646, 6.63968611],
      ],
      [
        [8.2758646, 6.63968611],
        [8.66486359, 6.63968611],
        [9.0218029, 6.42404699],
        [9.20277691, 6.07970858],
      ],
      [
        [9.20277691, 6.07970858],
        [9.88095856, 4.78932476],
      ],
      [
        [9.88095856, 4.78932476],
        [10.0188427, 4.52697182],
        [10.29079723, 4.36267519],
        [10.58717728, 4.36267519],
      ],
      [
        [10.58717728, 4.36267519],
        [13.41282368, 4.36267519],
      ],
      [
        [13.41282368, 4.36267519],
        [13.70920467, 4.36267519],
        [13.98115826, 4.52697182],
        [14.1190424, 4.78932476],
      ],
      [
        [14.1190424, 4.78932476],
        [14.797225, 6.07970858],
      ],
      [
        [14.797225, 6.07970858],
        [14.97819805, 6.42404699],
        [15.33513832, 6.63968611],
        [15.72413635, 6.63968611],
      ],
      [
        [15.72413635, 6.63968611],
        [18.38251495, 6.63968611],
      ],
      bodyCorner([18.38251495, 6.63968611], [21.25, 6.63968611], [21.25, 9.38217258], exponent),
      [
        [21.25, 9.38217258],
        [21.25, 16.3962059],
      ],
      bodyCorner([21.25, 16.3962059], [21.25, 19.63732529], [17.88388062, 19.63732529], exponent),
      [
        [17.88388062, 19.63732529],
        [6.11612034, 19.63732529],
      ],
      bodyCorner([6.11612034, 19.63732529], [2.75, 19.63732529], [2.75, 16.3962059], exponent),
      [
        [2.75, 16.3962059],
        [2.75, 9.38217258],
      ],
    ];
  throw new Error('Folder uses its two layered study forms');
}
/** Keep the actual Square curve segments, then replace only its removed upper band. */
function squarePortion(exponent: number, quarter: number, start: number, end: number): Profile[] {
  const rotate = ([x, y]: Point): Point =>
    quarter === 0
      ? [12 + x, 12 + y]
      : quarter === 1
        ? [12 - y, 12 + x]
        : quarter === 2
          ? [12 - x, 12 - y]
          : [12 + y, 12 - x];
  const vector = ([x, y]: Point): Point =>
    quarter === 0 ? [x, y] : quarter === 1 ? [-y, x] : quarter === 2 ? [-x, -y] : [y, -x];
  const cuts = [start];
  for (let i = 1; i < 32; i++) {
    const angle = (i * Math.PI) / 64;
    if (angle > start && angle < end) cuts.push(angle);
  }
  cuts.push(end);
  return cuts.slice(1).map((angle, i) => {
    const a = studyPoint(exponent, cuts[i]),
      b = studyPoint(exponent, angle),
      step = angle - cuts[i];
    const p0 = rotate(a.point),
      p1 = rotate(b.point),
      d0 = vector(a.tangent),
      d1 = vector(b.tangent);
    const profile: Profile = [
      p0,
      plus(p0, times(d0, step / 3)),
      minus(p1, times(d1, step / 3)),
      p1,
    ];
    profile.fitSteps = 1;
    return profile;
  });
}
type Layer = { cx: number; cy: number; rx: number; ry: number };
function layerPoint(exponent: number, angle: number, layer: Layer, offset = 0) {
  const c = Math.cos(angle),
    ss = Math.sin(angle),
    f = Math.abs(c) ** exponent + Math.abs(ss) ** exponent;
  const df =
    exponent *
    (-(Math.abs(c) ** (exponent - 2)) * c * ss + Math.abs(ss) ** (exponent - 2) * ss * c);
  const r = f ** (-1 / exponent),
    dr = (-r * df) / (exponent * f);
  const p: Point = [layer.cx + layer.rx * r * c, layer.cy + layer.ry * r * ss];
  const d: Point = [layer.rx * (dr * c - r * ss), layer.ry * (dr * ss + r * c)];
  const len = Math.hypot(...d),
    normal: Point = [d[1] / len, -d[0] / len];
  return { point: plus(p, times(normal, offset)), tangent: d };
}
function layerCurves(exponent: number, start: number, end: number, layer: Layer): Profile[] {
  const step = Math.PI / 64,
    cuts = [start];
  for (let k = Math.floor(start / step) + 1; k * step < end - 1e-10; k++) cuts.push(k * step);
  cuts.push(end);
  return cuts.slice(1).map((a, i) => {
    const p = layerPoint(exponent, cuts[i], layer),
      q = layerPoint(exponent, a, layer),
      h = a - cuts[i];
    const curve: Profile = [
      p.point,
      plus(p.point, times(p.tangent, h / 3)),
      minus(q.point, times(q.tangent, h / 3)),
      q.point,
    ];
    curve.fitSteps = 1;
    return curve;
  });
}
function curveRun(profiles: Profile[], offset: number, closed: boolean, roundedJoins = false) {
  let d = `M${xy(profilePoint(profiles[0], 0, offset).point)}`;
  for (let k = 0; k < profiles.length; k++) {
    const profile = profiles[k];
    if (k && roundedJoins) {
      const previous = profilePoint(profiles[k - 1], 1, offset).point,
        next = profilePoint(profile, 0, offset).point;
      if (Math.hypot(...minus(previous, next)) > 0.00001) {
        const center = profile[0],
          a = minus(previous, center),
          b = minus(next, center);
        const sweep = a[0] * b[1] - a[1] * b[0] > 0 ? 1 : 0;
        d += `A${Math.abs(offset)} ${Math.abs(offset)} 0 0 ${sweep} ${xy(next)}`;
      }
    }
    const count = profile.fitSteps ?? 32,
      step = 1 / count;
    for (let i = 0; i < count; i++) {
      const a = profilePoint(profile, i * step, offset),
        b = profilePoint(profile, (i + 1) * step, offset);
      d += `C${xy(plus(a.point, times(a.tangent, step / 3)))} ${xy(minus(b.point, times(b.tangent, step / 3)))} ${xy(b.point)}`;
    }
  }
  return d + (closed ? 'Z' : '');
}
/** Two own native squircle forms: front panel occludes a smaller rear form. */
function layeredFolder(exponent: number): StudyShape {
  const front: Layer = { cx: 12, cy: 12, rx: 10, ry: 3.5 };
  const rear: Layer = { cx: 7.5, cy: 8.1, rx: 4.4, ry: 3.2 };
  const frontY = (x: number) =>
    front.cy - front.ry * (1 - (Math.abs(x - front.cx) / front.rx) ** exponent) ** (1 / exponent);
  const difference = (angle: number) => {
    const p = layerPoint(exponent, angle, rear).point;
    return p[1] - frontY(p[0]);
  };
  const roots: number[] = [];
  let previous = 0,
    previousValue = difference(0);
  for (let i = 1; i <= 512; i++) {
    const angle = (i * 2 * Math.PI) / 512,
      value = difference(angle);
    if (value * previousValue < 0) {
      let lo = previous,
        hi = angle;
      for (let j = 0; j < 48; j++) {
        const mid = (lo + hi) / 2;
        if (difference(lo) * difference(mid) <= 0) hi = mid;
        else lo = mid;
      }
      roots.push((lo + hi) / 2);
    }
    previous = angle;
    previousValue = value;
  }
  if (roots.length !== 2) throw Error('Folder layers require two clean intersections');
  const rearStart = roots[1],
    rearEnd = roots[0] + 2 * Math.PI;
  const a = layerPoint(exponent, rearStart, rear).point,
    b = layerPoint(exponent, rearEnd, rear).point;
  const frontAngle = (x: number) =>
    Math.atan2(-(front.cy - frontY(x)) / front.ry, (x - front.cx) / front.rx) + 2 * Math.PI;
  const angleB = frontAngle(b[0]);
  const lower = [
    ...squarePortion(exponent, 0, 0, Math.PI / 2),
    ...squarePortion(exponent, 1, 0, Math.PI / 2),
  ];
  // Both layers share this actual Square side. It is drawn once: there is no
  // rear lower-left return or connector that turns back inward toward a tab stem.
  const shoulderAngle = 0.4,
    seamAngle = 0;
  const sharedLeft = squarePortion(exponent, 2, 0, shoulderAngle);
  const squareAt = (angle: number) => {
    const p = studyPoint(exponent, angle);
    return { point: [12 - p.point[0], 12 - p.point[1]] as Point, tangent: times(p.tangent, -1) };
  };
  const join = (p: Point, d: Point, q: Point, e: Point): Profile => {
    const delta = minus(q, p),
      det = d[0] * e[1] - d[1] * e[0];
    const t = (delta[0] * e[1] - delta[1] * e[0]) / det;
    const intersection = plus(p, times(d, t));
    return [
      p,
      plus(p, times(minus(intersection, p), 0.55)),
      plus(q, times(minus(intersection, q), 0.55)),
      q,
    ];
  };
  const shoulder = squareAt(shoulderAngle),
    rearTop = layerPoint(exponent, 1.5 * Math.PI, rear);
  const roof = join(shoulder.point, shoulder.tangent, rearTop.point, rearTop.tangent);
  const upperRight = layerCurves(exponent, angleB, 2 * Math.PI, front);
  const behind = layerCurves(exponent, 1.5 * Math.PI, rearEnd, rear);
  const seamStart = squareAt(seamAngle),
    seamEnd = layerPoint(exponent, 4.2, front);
  const frontShoulder = join(seamStart.point, seamStart.tangent, seamEnd.point, seamEnd.tangent);
  // Uniform recentering preserves the accepted lower curve vectors and fixed native weight.
  const shift = 12 - (rear.cy - rear.ry + 22) / 2;
  const move = (profiles: Profile[]) =>
    profiles.map((profile) => {
      const p: Profile = profile.map(([x, y]): Point => [x, y + shift]);
      p.fitSteps = profile.fitSteps;
      return p;
    });
  const union = move([...lower, ...sharedLeft, roof, ...behind, ...upperRight]);
  const frontEdge = move([frontShoulder, ...layerCurves(exponent, 4.2, angleB, front)]);
  const outline =
    curveRun(union, -STUDY_STROKE / 2, true, true) + curveRun(frontEdge, -STUDY_STROKE / 2, false);
  const startX = a[0] + 1.8,
    endX = b[0] - 1.5;
  const counter = move(layerCurves(exponent, frontAngle(startX), frontAngle(endX), front));
  const first = profilePoint(counter[0], 0, 0).point;
  const innerLast = profilePoint(counter.at(-1)!, 1, -STUDY_STROKE).point;
  const reverse: Profile[] = counter
    .slice()
    .reverse()
    .map((profile) => {
      const p: Profile = profile.slice().reverse();
      p.fitSteps = profile.fitSteps;
      return p;
    });
  const backwards = curveRun(reverse, STUDY_STROKE, false).replace(/^M[^C]+/, '');
  const hole =
    curveRun(counter, 0, false) +
    `A.75 .75 0 0 1 ${xy(innerLast)}` +
    backwards +
    `A.75 .75 0 0 1 ${xy(first)}Z`;
  return { outline, filled: curveRun(union, 0, true) + hole };
}
function originalBody(profiles: Profile[], offset: number) {
  let d = `M${xy(profilePoint(profiles[0], 0, offset).point)}`;
  for (const profile of profiles) {
    if (profile.length === 2) {
      d += `L${xy(profilePoint(profile, 1, offset).point)}`;
      continue;
    }
    const count = profile.fitSteps ?? 32,
      step = 1 / count;
    for (let i = 0; i < count; i++) {
      const a = profilePoint(profile, i * step, offset),
        b = profilePoint(profile, (i + 1) * step, offset);
      d += `C${xy(plus(a.point, times(a.tangent, step / 3)))} ${xy(minus(b.point, times(b.tangent, step / 3)))} ${xy(b.point)}`;
    }
  }
  return d + 'Z';
}
const circlePath = (x: number, y: number, r: number) =>
  `M${round(x - r)} ${round(y)}a${round(r)} ${round(r)} 0 1 0 ${round(2 * r)} 0a${round(r)} ${round(r)} 0 1 0 ${round(-2 * r)} 0Z`;

/** Three original subject prototypes; never substituted into the production icon catalog. */
export function prototypeStudy(subject: StudySubject, exponent = DEFAULT_ROUNDNESS): StudyShape {
  if (subject === 'square') return squircleStudy(exponent);
  if (subject !== 'camera' && subject !== 'folder') throw new RangeError('Unknown study subject');
  if (!Number.isFinite(exponent) || exponent < 2 || exponent > 5)
    throw new RangeError('Study exponent must be between2 and5');
  if (subject === 'folder') return layeredFolder(exponent);
  const profiles = originalProfiles(subject, exponent),
    half = STUDY_STROKE / 2;
  const centerline = originalBody(profiles, 0),
    exterior = originalBody(profiles, half);
  if (subject === 'camera') {
    const lensY = 12.8227459,
      indicatorY = 9.13285542,
      lensRadius = 3.24112022;
    return {
      outline:
        centerline +
        circlePath(12, lensY, lensRadius) +
        `M17.88388062 ${indicatorY}L17.88388062 ${indicatorY}`,
      filled:
        exterior +
        circlePath(12, lensY, lensRadius - half) +
        circlePath(17.88388062, indicatorY, half),
    };
  }
  throw new Error('Unreachable study subject');
}
/** Explicit comparison references, not additional production icons. */
export function studyReference(kind: 'rounded-square' | 'circle'): StudyShape {
  if (kind === 'circle')
    return {
      outline: 'M21.25 12A9.25 9.25 0 1 1 2.75 12A9.25 9.25 0 1 1 21.25 12Z',
      filled: 'M22 12A10 10 0 1 1 2 12A10 10 0 1 1 22 12Z',
    };
  return {
    outline:
      'M8 2.75H16A5.25 5.25 0 0 1 21.25 8V16A5.25 5.25 0 0 1 16 21.25H8A5.25 5.25 0 0 1 2.75 16V8A5.25 5.25 0 0 1 8 2.75Z',
    filled: 'M8 2H16A6 6 0 0 1 22 8V16A6 6 0 0 1 16 22H8A6 6 0 0 1 2 16V8A6 6 0 0 1 8 2Z',
  };
}
