/** Independent base-shape study. Not approved production icon/frame geometry. */
export const STUDY_STROKE = 1.5;
export const DEFAULT_ROUNDNESS = 3.2;
type Point = [number, number];
export type StudyShape = { outline: string; filled: string };
export type StudySubject = 'square' | 'camera' | 'folder';
const round = (n: number) => String(Number(n.toFixed(7)));
const xy = (p: Point) => p.map(round).join(' ');

/** A full-contour superellipse, with an inward normal offset for the stroke centerline. */
export function studyPoint(exponent: number, angle: number, inset = 0) {
  const c = Math.max(0, Math.cos(angle)),
    s = Math.max(0, Math.sin(angle));
  const f = c ** exponent + s ** exponent;
  const df = exponent * (-(c ** (exponent - 1)) * s + s ** (exponent - 1) * c);
  const r = 10 * f ** (-1 / exponent),
    dr = (-r * df) / (exponent * f);
  const g: Point = [c ** (exponent - 1), s ** (exponent - 1)];
  const dg: Point = [
    -(exponent - 1) * c ** (exponent - 2) * s,
    (exponent - 1) * s ** (exponent - 2) * c,
  ];
  const len = Math.hypot(...g),
    dot = (g[0] * dg[0] + g[1] * dg[1]) / len ** 2;
  const n: Point = [g[0] / len, g[1] / len];
  const dn: Point = [(dg[0] - g[0] * dot) / len, (dg[1] - g[1] * dot) / len];
  return {
    point: [r * c - inset * n[0], r * s - inset * n[1]] as Point,
    tangent: [dr * c - r * s - inset * dn[0], dr * s + r * c - inset * dn[1]] as Point,
  };
}
function contour(exponent: number, inset: number) {
  const rotate = ([x, y]: Point, q: number): Point =>
    q === 0
      ? [12 + x, 12 + y]
      : q === 1
        ? [12 - y, 12 + x]
        : q === 2
          ? [12 - x, 12 - y]
          : [12 + y, 12 - x];
  const segments = 32,
    step = Math.PI / 2 / segments;
  let d = `M${xy(rotate(studyPoint(exponent, 0, inset).point, 0))}`;
  for (let q = 0; q < 4; q++)
    for (let i = 0; i < segments; i++) {
      const a = studyPoint(exponent, i * step, inset),
        b = studyPoint(exponent, (i + 1) * step, inset);
      d += `C${xy(rotate([a.point[0] + (a.tangent[0] * step) / 3, a.point[1] + (a.tangent[1] * step) / 3], q))} ${xy(rotate([b.point[0] - (b.tangent[0] * step) / 3, b.point[1] - (b.tangent[1] * step) / 3], q))} ${xy(rotate(b.point, q))}`;
    }
  return d + 'Z';
}
export function squircleStudy(exponent = DEFAULT_ROUNDNESS): StudyShape {
  if (!Number.isFinite(exponent) || exponent < 2 || exponent > 5)
    throw new RangeError('Study exponent must be between2 and5');
  return { outline: contour(exponent, STUDY_STROKE / 2), filled: contour(exponent, 0) };
}

type Profile = Point[];
const plus = (a: Point, b: Point): Point => [a[0] + b[0], a[1] + b[1]];
const times = (p: Point, k: number): Point => [p[0] * k, p[1] * k];
const minus = (a: Point, b: Point): Point => plus(a, times(b, -1));
function bezier(points: Profile, t: number): Point {
  let row = points;
  while (row.length > 1) row = row.slice(1).map((p, i) => plus(times(row[i], 1 - t), times(p, t)));
  return row[0];
}
const derivative = (points: Profile) =>
  points.slice(1).map((p, i) => times(minus(p, points[i]), points.length - 1));
function profilePoint(profile: Profile, t: number, offset: number) {
  const p = bezier(profile, t),
    d = bezier(derivative(profile), t),
    dd = profile.length > 2 ? bezier(derivative(derivative(profile)), t) : [0, 0];
  const speed = Math.hypot(...d),
    normal: Point = [d[1] / speed, -d[0] / speed];
  const dot = (d[0] * dd[0] + d[1] * dd[1]) / speed ** 2;
  const dn: Point = [dd[1] / speed - normal[0] * dot, -dd[0] / speed - normal[1] * dot];
  return { point: plus(p, times(normal, offset)), tangent: plus(d, times(dn, offset)) };
}
/** Only the large main-body corners receive the progressive family treatment. */
function bodyCorner(a: Point, b: Point, c: Point, exponent: number): Profile {
  const k = 0.26 + 0.035 * (exponent - 2);
  return [
    a,
    plus(a, times(minus(b, a), k)),
    plus(a, times(minus(b, a), 2 * k)),
    plus(c, times(minus(b, c), 2 * k)),
    plus(c, times(minus(b, c), k)),
    c,
  ];
}
function originalProfiles(subject: 'camera' | 'folder', exponent: number): Profile[] {
  if (subject === 'camera')
    return [
      bodyCorner([2.75, 9.38217258], [2.75, 6.63968611], [5.61748648, 6.63968611], exponent),
      [
        [5.61748648, 6.63968611],
        [8.2758646, 6.63968611],
      ],
      [
        [8.2758646, 6.63968611],
        [8.66486359, 6.63968611],
        [9.0218029, 6.42404699],
        [9.20277691, 6.07970858],
      ],
      [
        [9.20277691, 6.07970858],
        [9.88095856, 4.78932476],
      ],
      [
        [9.88095856, 4.78932476],
        [10.0188427, 4.52697182],
        [10.29079723, 4.36267519],
        [10.58717728, 4.36267519],
      ],
      [
        [10.58717728, 4.36267519],
        [13.41282368, 4.36267519],
      ],
      [
        [13.41282368, 4.36267519],
        [13.70920467, 4.36267519],
        [13.98115826, 4.52697182],
        [14.1190424, 4.78932476],
      ],
      [
        [14.1190424, 4.78932476],
        [14.797225, 6.07970858],
      ],
      [
        [14.797225, 6.07970858],
        [14.97819805, 6.42404699],
        [15.33513832, 6.63968611],
        [15.72413635, 6.63968611],
      ],
      [
        [15.72413635, 6.63968611],
        [18.38251495, 6.63968611],
      ],
      bodyCorner([18.38251495, 6.63968611], [21.25, 6.63968611], [21.25, 9.38217258], exponent),
      [
        [21.25, 9.38217258],
        [21.25, 16.3962059],
      ],
      bodyCorner([21.25, 16.3962059], [21.25, 19.63732529], [17.88388062, 19.63732529], exponent),
      [
        [17.88388062, 19.63732529],
        [6.11612034, 19.63732529],
      ],
      bodyCorner([6.11612034, 19.63732529], [2.75, 19.63732529], [2.75, 16.3962059], exponent),
      [
        [2.75, 16.3962059],
        [2.75, 9.38217258],
      ],
    ];
  return [
    bodyCorner([2.75, 6.98354101], [2.75, 4.1911912], [5.66734982, 4.1911912], exponent),
    [
      [5.66734982, 4.1911912],
      [8.07275391, 4.1911912],
    ],
    [
      [8.07275391, 4.1911912],
      [8.28825283, 4.1911912],
      [8.49458694, 4.27836895],
      [8.64480209, 4.4328866],
    ],
    [
      [8.64480209, 4.4328866],
      [10.89379501, 6.74629974],
    ],
    [
      [10.89379501, 6.74629974],
      [11.09095097, 6.94910383],
      [11.36176491, 7.06352472],
      [11.6446085, 7.06352472],
    ],
    [
      [11.6446085, 7.06352472],
      [18.13319778, 7.06352472],
    ],
    bodyCorner([18.13319778, 7.06352472], [21.25, 7.06352472], [21.25, 10.05532837], exponent),
    [
      [21.25, 10.05532837],
      [21.25, 16.56768799],
    ],
    bodyCorner([21.25, 16.56768799], [21.25, 19.80880928], [17.88388062, 19.80880928], exponent),
    [
      [17.88388062, 19.80880928],
      [6.11612034, 19.80880928],
    ],
    bodyCorner([6.11612034, 19.80880928], [2.75, 19.80880928], [2.75, 16.56768799], exponent),
    [
      [2.75, 16.56768799],
      [2.75, 6.98354101],
    ],
  ];
}
function originalBody(profiles: Profile[], offset: number) {
  let d = `M${xy(profilePoint(profiles[0], 0, offset).point)}`;
  for (const profile of profiles) {
    if (profile.length === 2) {
      d += `L${xy(profilePoint(profile, 1, offset).point)}`;
      continue;
    }
    const count = 32,
      step = 1 / count;
    for (let i = 0; i < count; i++) {
      const a = profilePoint(profile, i * step, offset),
        b = profilePoint(profile, (i + 1) * step, offset);
      d += `C${xy(plus(a.point, times(a.tangent, step / 3)))} ${xy(minus(b.point, times(b.tangent, step / 3)))} ${xy(b.point)}`;
    }
  }
  return d + 'Z';
}
const circlePath = (x: number, y: number, r: number) =>
  `M${round(x - r)} ${round(y)}a${round(r)} ${round(r)} 0 1 0 ${round(2 * r)} 0a${round(r)} ${round(r)} 0 1 0 ${round(-2 * r)} 0Z`;

/** Three original subject prototypes; never substituted into the production icon catalog. */
export function prototypeStudy(subject: StudySubject, exponent = DEFAULT_ROUNDNESS): StudyShape {
  if (subject === 'square') return squircleStudy(exponent);
  if (subject !== 'camera' && subject !== 'folder') throw new RangeError('Unknown study subject');
  if (!Number.isFinite(exponent) || exponent < 2 || exponent > 5)
    throw new RangeError('Study exponent must be between2 and5');
  const profiles = originalProfiles(subject, exponent),
    half = STUDY_STROKE / 2;
  const centerline = originalBody(profiles, 0),
    exterior = originalBody(profiles, half);
  if (subject === 'camera') {
    const lensY = 12.8227459,
      indicatorY = 9.13285542,
      lensRadius = 3.24112022;
    return {
      outline:
        centerline +
        circlePath(12, lensY, lensRadius) +
        `M17.88388062 ${indicatorY}L17.88388062 ${indicatorY}`,
      filled:
        exterior +
        circlePath(12, lensY, lensRadius - half) +
        circlePath(17.88388062, indicatorY, half),
    };
  }
  const y = 10.9030056,
    left = 4.76980874 + half,
    right = 19.23019126 - half;
  const slot = `M${round(left)} ${round(y - half)}H${round(right)}a${half} ${half} 0 0 1 0 ${STUDY_STROKE}H${round(left)}a${half} ${half} 0 0 1 0 ${-STUDY_STROKE}Z`;
  return { outline: centerline + `M2.75 ${y}H21.25`, filled: exterior + slot };
}
/** Explicit comparison references, not additional production icons. */
export function studyReference(kind: 'rounded-square' | 'circle'): StudyShape {
  if (kind === 'circle')
    return {
      outline: 'M21.25 12A9.25 9.25 0 1 1 2.75 12A9.25 9.25 0 1 1 21.25 12Z',
      filled: 'M22 12A10 10 0 1 1 2 12A10 10 0 1 1 22 12Z',
    };
  return {
    outline:
      'M8 2.75H16A5.25 5.25 0 0 1 21.25 8V16A5.25 5.25 0 0 1 16 21.25H8A5.25 5.25 0 0 1 2.75 16V8A5.25 5.25 0 0 1 8 2.75Z',
    filled: 'M8 2H16A6 6 0 0 1 22 8V16A6 6 0 0 1 16 22H8A6 6 0 0 1 2 16V8A6 6 0 0 1 8 2Z',
  };
}
