# Icon batches

Owner workflow recorded on 2026-10-27: an add-icons request means six icons total. Explicitly named icons occupy places in that same batch. Choose complementary icons for all remaining places automatically.

| Round | Icons                                                                                                          | Current review status                          |
| ----- | -------------------------------------------------------------------------------------------------------------- | ---------------------------------------------- |
| 1     | Bell, Camera, Folder, Heart, Search, Settings                                                                  | All six approved                               |
| 2     | Sun, Moon                                                                                                      | Both approved                                  |
| 3     | X, Copy, Chevron Down, Plus, Check, Chevron Up                                                                 | Chevron Up/Down reopened; other four approved  |
| 4     | Arrow Left, Arrow Right, Menu, Download, Upload, Trash                                                         | Arrow Left/Right reopened; other four approved |
| 5     | Arrow Up, Arrow Down, Arrow Up Left, Arrow Up Right, Arrow Down Left, Arrow Down Right                         | All six await review                           |
| 6     | Chevron Left, Chevron Right, Double Chevron Up, Double Chevron Down, Double Chevron Left, Double Chevron Right | All six await review                           |

**16 of32 current icon pairs are approved; eight Arrow directions and four Single/four Double Chevron directions with their frames await review.** The owner approved Sun with3px visible rays in both styles on2026-10-27. Approval covers both Outline and Filled. Automated checks do not grant visual approval.

## Batch membership

Round 3 includes three owner selections (X / close, Copy, Chevron Down) and three complementary selections (Plus, Check, Chevron Up). It contains six icons total, not six in addition to the named selections. All six provide Outline and Filled artwork. The batch rule begins with Round 3 and does not require retroactively expanding Round 2.

Round 4 adds navigation directions, Menu, file transfer and Trash. All six provide Outline and Filled artwork. No new batch is created when revising an existing icon or adding its Filled style.

## Accepted revisions

The owner approved Camera, Folder, Plus and X on 2026-10-27. Camera/Folder retain natural horizontal proportions, exact 2px left/right margins, rounder main-body corners and matching unboxed Filled exteriors. Camera includes the lowered raised housing. Plus/X keep radius-4 boxes at2..22 and identical shared glyphs at4..20. See ICON_MARGIN_RULES.md and BOXED_ICON_RULES.md for exact dimensions.

Copy was approved on 2026-10-27 with 4px exposed parallel-page spacing, standard radius-3.25 centerline corners (radius-4.10 Filled exterior), 1px breaks at both rear/front junctions and 2px artboard margins.

The earlier boxed Search was approved, then superseded by the owner's **Filled = Bold** direction for Menu and Search. On 2026-10-27 the owner approved their current unboxed pairs: fixed Bold 2.25 Filled following the same centerlines as Regular 1.70 Outline. Filled has 2px on its primary pair (Menu left/right; Search both pairs); Regular Outline has 2.275px at the same pair. The former boxed treatment is not the current reference.

The owner accepted current Trash on 2026-10-27: straight vertical bucket sides, standard radius-3.25 base centerline corners, fitted radius-1 handle centerline corners, aligned unboxed Filled exterior and 2px top/bottom primary margins. Preserve the accepted small-handle exception; it is part of this approval.

Trash approval-pose correction (2026-10-27): the owner reviewed and accepted X=105%, Y=95%, Regular 1.70 and rotation=0 in both styles. The earlier 100%/100% approval record was incorrect. Preserve the original SVG geometry and its native margin measurements; use metadata labDefaults 105/95 for opening or resetting Trash in Lab. Draft adjustments still take priority while switching icons. Trash remains approved, with 13 approved pairs total.

Trash native-size correction (2026-10-27), superseding the preceding Lab-default correction: bake the accepted 105%/95% centerline proportions into both source drawings and return Lab X/Y to100%/100%. Keep Regular1.70 and round .85 caps. Reconstruct Filled from the baked Outline exterior so both styles align. New native visible bounds x=2.75..21.25/y=2.4575..21.5425 (18.5×19.085); the earlier 2px native top/bottom measurements are historical. Base centerline radii become rx3.4125/ry3.0875; handle rx1.05/ry.95. Trash stays owner-approved. No105/95 Lab-default override remains.

Arrow-family feedback (2026-10-27): the owner rejected the broad curved-head experiment. Restore the original straight-arm V heads for Arrow Left/Right, Chevron Up/Down and Download/Upload, retaining round caps/joins and matching Filled contours. All six pairs remain drafts;13 of20 current pairs stay approved.

Current Check/arrow Filled revision (2026-10-27): add the accepted rounded-box treatment to Check Filled and make all six Filled arrowheads solid triangles. Outline arrow heads remain open V shapes. These are the seven existing pending pairs;13 of20 pairs remain approved.

Owner approval (2026-10-27), corrected by the owner: Check and four navigation Arrow/Chevron pairs passed in both styles. Download and Upload remain pending. Check uses the rounded box; Filled arrows have solid triangular heads.18 current pairs are approved. Chevron Up/Down remain unified names for each icon in both Outline/Filled styles. Caret is an alternate search term; it does not mean a separate icon or a required Filled-only name.

Approval correction (2026-10-27): the owner clarified that only Download and Upload remain pending. Their earlier approval was recorded in error and has been reverted to draft in both styles. Current approved count is18 of20; all other current pairs are approved.

Pending Download/Upload refinement (2026-10-27): both trays now use the standard Camera/Folder radius3.25 centerline corners, matching Filled outer4.10/inner2.40 radii and unchanged .85 caps. Heads, shafts and native outer bounds are retained. Both pairs still await owner review.

Moon inner-crescent revision (2026-10-27): keep outer radius8, horns, bounds and weight; reduce the inner radius10→9 for a .63324958-unit deeper and longer arc. The revised pair reopens review;17 pairs are approved and Download/Moon/Upload remain pending.

Moon fullness correction (2026-10-27), superseding the preceding deeper-arc revision: the owner rejected radius9 because it made the body thinner. Use inner centerline radius14, moving the inner midpoint1.83215957 units toward the opening and making the crescent substantially fuller. Preserve outer radius8, horn locations, bounds, centering, Regular1.70 and .85 joins. Filled uses outer8.85/inner13.15. The revised pair remains pending;17 pairs stay approved.

Confirmed Moon horn extension (2026-10-27), superseding the curvature experiments: the owner confirmed keeping the previously approved concavity and lengthening both horns. Use inner centerline radius10 and outer8; extend each horn15 degrees along the outer circle (+4.18879020 units total arc). Refit the same radius10 circle through the new ends and uniformly recenter the whole drawing; no independent style scaling. Filled uses8.85/9.15 circles and .85 joins. Native visible margin3.20252287, width/height17.59495426; X/Y100%. The revised pair remains pending, with17 approved pairs.

Moon deeper concavity after horn extension (2026-10-27): Owner requested a deeper Moon concavity after the horn-extension revision. Preserve the extended horn endpoints, outer radius8, placement, bounds, Regular1.70 and round .85 joins. Reduce the inner centerline radius10 to9 and refit its circle through the unchanged horns. Filled follows the exact Regular exterior with outer radius8.85, inner radius8.15 and .85 horn joins. Both styles remain pending owner review. The new inner-circle center is 19.75836822 4.24163178. Native margins remain3.20252287.17 of20 pairs remain approved.

Moon concavity beyond center (2026-10-27), superseding radius9: Owner requested substantially deeper concavity, with the inner arc extending beyond the artboard center. Preserve both extended horns, outer radius8, native bounds, placement and Regular1.70. Fit inner centerline radius6.52 through the unchanged horns. Filled uses the exact Regular exterior: outer radius8.85, inner radius5.67 and round .85 horn joins. The visible concave midpoint is11.73755556 12.26244444, beyond12,12 toward the crescent body; the center is inside the opening in both styles. Both styles remain pending owner review. The new inner-circle center is 15.74685101 8.25314899. Native margins remain3.20252287.17 of20 pairs remain approved.

Moon concavity centered at local0,0 (2026-10-27), superseding beyond-center revision: Owner clarified the concavity target: its deepest visible edge must coincide exactly with the icon center, treated as local0,0. Preserve both extended horns, outer radius8, position, native bounds, Regular1.70 and round .85 joins. Fit inner centerline radius6.569189459166889 so its inward visible edge at Regular1.70 reaches12,12 exactly. Filled is the exact Regular exterior: outer radius8.85, inner radius5.719189459166889 and .85 horn joins. Centerline midpoint11.39895924 12.60104076; shared visible concave midpoint12 12. Both styles remain pending owner review. The new inner-circle center is 16.04407765 7.95592235. Native margins remain3.20252287.17 of20 pairs remain approved.

Moon concave point moved to local2,2 (2026-10-27), superseding the circle-center interpretation: Owner corrected the interpretation: move the concave edge point, not the circle center, to local2,2 relative to the artboard center. The requested visible edge point is14,14. Keep inner center18.04407765 9.95592235 and centerline radius6.569189459166889. Preserve the radius8 outer-circle shape, Regular1.70 and .85 horn joins; place the outer center at12.65789151 12 and recompute intersections so the complete source is centered without moving the requested edge point. Filled uses exact outer8.85 and inner5.719189459166889 offsets and .85 joins. Native visible margins are left/right3.80789151 and top/bottom3.15. Both styles remain pending owner review. The new inner-circle center is 18.04407765 9.95592235.17 of20 pairs remain approved.

Owner approval completed on2026-10-27: Moon passed at -30 degrees and Download/Upload passed in both styles. All20 current icon pairs are approved. Moon’s accepted pose is baked into source and becomes native0 degrees at X/Y100%, preserving Regular1.70 and exact Outline/Filled contours. Recenter both styles uniformly; no independent scaling. Download/Upload geometry is unchanged.

Sun ray-length trial (2026-10-27): Owner requested a trial of longer Sun rays on2026-10-27. Each ray is3px long measured to the visible rounded ends at native24px and Regular1.70: centerline length1.30, spanning radial distance7.90..9.20, plus .85 caps at each end. Extend only the inner endpoint by.30; preserve the outer tips, disc radius5.10 (Filled5.95), stroke1.70, native X/Y100%, rotation0 and equal margins1.95. Filled rays are exact radius-.85 capsules around the same centerlines. The Sun Moon morph derives its Sun endpoint from this source automatically. This trial replaces the previously approved2.70px rays and awaits owner review;19 of20 pairs remain approved.

Sun3px rays were owner-approved on2026-10-27. Use this approved source for the Sun Moon morph endpoint. All20 static pairs are approved.

Round5 (2026-10-27): the owner requested the complete arrow set. Add the six missing compass directions to existing Arrow Left/Right, giving eight directional arrows. Each new icon provides open V Outline and solid-head Filled, fixed Regular1.70, round .85 exterior, and2px at its primary opposing pair (Up/Down top/bottom; diagonals both pairs). The original20 approved pairs and both morphs remain unchanged. All six new pairs are drafts until owner approval.

Owner compass-arrow size correction (2026-10-27): all8 directional arrows must use the same physical shaft length18.25, identical head-arm lengths and Regular1.75. Derive each direction by rotation about12,12; do not independently enlarge diagonals to touch all four artboard edges. Cardinals have2px at their primary pair. Diagonal visible X/Y margins are4.67265062, preserving the same physical size. This explicit owner correction supersedes earlier diagonal all-side2px fits and normalizes Left/Right with Up/Down.

## Current framed arrow family — 2026-10-27

The owner requested smaller, equal arrows with room for Square/Circle frames. This supersedes the previous18.25-unit shaft and standalone2px edge rule. All8 directions now share a12.25-unit shaft, identical head arms and1.75 stroke. Standalone and framed arrows use exactly the same glyph, position and size. Add frame variants to the existing8 arrow identities; this is a construction revision, not a new six-icon batch. Square/Circle outer frames have2px artboard margins; Square exterior radius4, Circle radius10. Outline frame centerlines are inset by.875. Filled frames use negative space cut from a solid frame, preserving the standalone Filled solid-head silhouette. The glyph has14px visible length along its own axis; cardinal standalone primary margins are5px and diagonal margins6.79397097px. Circle inner clearance is1.25px at Regular and.5px at Bold2.50. Directional rotation never rotates the Square frame. All8 arrow pairs and their new frames await owner review;18 of26 standalone pairs remain approved.

## Current Chevron family — 2026-10-27

Apply the same Arrow concept to Chevron:8 directions times None/Square/Circle =24 variants, with Outline/Filled for each. Round6 adds the six missing directions to existing Up/Down. Use equal90-degree V arms of length5.5*sqrt(2), endpoints at(-5.5,2.75),(0,-2.75),(5.5,2.75) before rotation. Rotate and uniformly recenter the bounding box at12,12; never scale directions independently. The same glyph/placement appears in all frames. Filled closes and expands the same triangle at half Regular.875; framed Filled subtracts that exact silhouette. Reuse Arrow frame geometry:2px exterior margins, Square exterior radius4, Circle radius10. At Bold2.50 the circular border still clears all Chevron vertices by at least.4758px. Up/Down review reopens for the new smaller shared glyph. The catalog now contains32 standalone identities:16 approved and16 directional Arrow/Chevron pairs awaiting review. Each directional family contains24 variants; styles do not change that count.

## Chevron owner clarification — four directions plus Double (2026-10-27)

Supersedes the earlier eight-direction Chevron proposal. The owner explicitly excludes diagonal Chevron icons. Keep Single Chevron in Up/Down/Left/Right and add Double Chevron in the same four directions (`chevrons-up/down/left/right`). Each of these8 identities supports None/Square/Circle with Outline/Filled:24 variants total. Single V geometry stays unchanged. Double uses two equal V marks with local vertices(-4,2),(0,-2),(4,2), shifted by -3/+3 along the vertical axis before cardinal rotation. Rotate and center without scaling; reuse exactly the same glyph in all frames. Filled closes and expands both triangles at.875, retaining.25px between them; framed Filled subtracts that same silhouette. All Arrow frame dimensions remain unchanged. Double retains at least.2218px circular clearance at Bold2.50. The total catalog remains32 identities,16 approved and16 pending directional pairs. No diagonal Chevron components or exports remain.
