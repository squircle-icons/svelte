# Icon batches

Owner workflow recorded on 2026-10-27: an add-icons request means six icons total. Explicitly named icons occupy places in that same batch. Choose complementary icons for all remaining places automatically.

| Round | Icons                                                  | Current review status                      |
| ----- | ------------------------------------------------------ | ------------------------------------------ |
| 1     | Bell, Camera, Folder, Heart, Search, Settings          | All six approved                           |
| 2     | Sun, Moon                                              | Sun approved; revised Moon awaits review   |
| 3     | X, Copy, Chevron Down, Plus, Check, Chevron Up         | All six approved                           |
| 4     | Arrow Left, Arrow Right, Menu, Download, Upload, Trash | Four approved; Download and Upload pending |

**17 of20 current icon pairs are approved.** Download, revised Moon and Upload await review in both styles. Approval covers both Outline and Filled. Automated checks do not grant visual approval.

## Batch membership

Round 3 includes three owner selections (X / close, Copy, Chevron Down) and three complementary selections (Plus, Check, Chevron Up). It contains six icons total, not six in addition to the named selections. All six provide Outline and Filled artwork. The batch rule begins with Round 3 and does not require retroactively expanding Round 2.

Round 4 adds navigation directions, Menu, file transfer and Trash. All six provide Outline and Filled artwork. No new batch is created when revising an existing icon or adding its Filled style.

## Accepted revisions

The owner approved Camera, Folder, Plus and X on 2026-10-27. Camera/Folder retain natural horizontal proportions, exact 2px left/right margins, rounder main-body corners and matching unboxed Filled exteriors. Camera includes the lowered raised housing. Plus/X keep radius-4 boxes at2..22 and identical shared glyphs at4..20. See ICON_MARGIN_RULES.md and BOXED_ICON_RULES.md for exact dimensions.

Copy was approved on 2026-10-27 with 4px exposed parallel-page spacing, standard radius-3.25 centerline corners (radius-4.10 Filled exterior), 1px breaks at both rear/front junctions and 2px artboard margins.

The earlier boxed Search was approved, then superseded by the owner's **Filled = Bold** direction for Menu and Search. On 2026-10-27 the owner approved their current unboxed pairs: fixed Bold 2.25 Filled following the same centerlines as Regular 1.70 Outline. Filled has 2px on its primary pair (Menu left/right; Search both pairs); Regular Outline has 2.275px at the same pair. The former boxed treatment is not the current reference.

The owner accepted current Trash on 2026-10-27: straight vertical bucket sides, standard radius-3.25 base centerline corners, fitted radius-1 handle centerline corners, aligned unboxed Filled exterior and 2px top/bottom primary margins. Preserve the accepted small-handle exception; it is part of this approval.

Trash approval-pose correction (2026-10-27): the owner reviewed and accepted X=105%, Y=95%, Regular 1.70 and rotation=0 in both styles. The earlier 100%/100% approval record was incorrect. Preserve the original SVG geometry and its native margin measurements; use metadata labDefaults 105/95 for opening or resetting Trash in Lab. Draft adjustments still take priority while switching icons. Trash remains approved, with 13 approved pairs total.

Trash native-size correction (2026-10-27), superseding the preceding Lab-default correction: bake the accepted 105%/95% centerline proportions into both source drawings and return Lab X/Y to100%/100%. Keep Regular1.70 and round .85 caps. Reconstruct Filled from the baked Outline exterior so both styles align. New native visible bounds x=2.75..21.25/y=2.4575..21.5425 (18.5×19.085); the earlier 2px native top/bottom measurements are historical. Base centerline radii become rx3.4125/ry3.0875; handle rx1.05/ry.95. Trash stays owner-approved. No105/95 Lab-default override remains.

Arrow-family feedback (2026-10-27): the owner rejected the broad curved-head experiment. Restore the original straight-arm V heads for Arrow Left/Right, Chevron Up/Down and Download/Upload, retaining round caps/joins and matching Filled contours. All six pairs remain drafts;13 of20 current pairs stay approved.

Current Check/arrow Filled revision (2026-10-27): add the accepted rounded-box treatment to Check Filled and make all six Filled arrowheads solid triangles. Outline arrow heads remain open V shapes. These are the seven existing pending pairs;13 of20 pairs remain approved.

Owner approval (2026-10-27), corrected by the owner: Check and four navigation Arrow/Chevron pairs passed in both styles. Download and Upload remain pending. Check uses the rounded box; Filled arrows have solid triangular heads.18 current pairs are approved. Chevron Up/Down remain unified names for each icon in both Outline/Filled styles. Caret is an alternate search term; it does not mean a separate icon or a required Filled-only name.

Approval correction (2026-10-27): the owner clarified that only Download and Upload remain pending. Their earlier approval was recorded in error and has been reverted to draft in both styles. Current approved count is18 of20; all other current pairs are approved.

Pending Download/Upload refinement (2026-10-27): both trays now use the standard Camera/Folder radius3.25 centerline corners, matching Filled outer4.10/inner2.40 radii and unchanged .85 caps. Heads, shafts and native outer bounds are retained. Both pairs still await owner review.

Moon inner-crescent revision (2026-10-27): keep outer radius8, horns, bounds and weight; reduce the inner radius10→9 for a .63324958-unit deeper and longer arc. The revised pair reopens review;17 pairs are approved and Download/Moon/Upload remain pending.

Moon fullness correction (2026-10-27), superseding the preceding deeper-arc revision: the owner rejected radius9 because it made the body thinner. Use inner centerline radius14, moving the inner midpoint1.83215957 units toward the opening and making the crescent substantially fuller. Preserve outer radius8, horn locations, bounds, centering, Regular1.70 and .85 joins. Filled uses outer8.85/inner13.15. The revised pair remains pending;17 pairs stay approved.

Confirmed Moon horn extension (2026-10-27), superseding the curvature experiments: the owner confirmed keeping the previously approved concavity and lengthening both horns. Use inner centerline radius10 and outer8; extend each horn15 degrees along the outer circle (+4.18879020 units total arc). Refit the same radius10 circle through the new ends and uniformly recenter the whole drawing; no independent style scaling. Filled uses8.85/9.15 circles and .85 joins. Native visible margin3.20252287, width/height17.59495426; X/Y100%. The revised pair remains pending, with17 approved pairs.

Moon deeper concavity after horn extension (2026-10-27): Owner requested a deeper Moon concavity after the horn-extension revision. Preserve the extended horn endpoints, outer radius8, placement, bounds, Regular1.70 and round .85 joins. Reduce the inner centerline radius10 to9 and refit its circle through the unchanged horns. Filled follows the exact Regular exterior with outer radius8.85, inner radius8.15 and .85 horn joins. Both styles remain pending owner review. The new inner-circle center is 19.75836822 4.24163178. Native margins remain3.20252287.17 of20 pairs remain approved.

Moon concavity beyond center (2026-10-27), superseding radius9: Owner requested substantially deeper concavity, with the inner arc extending beyond the artboard center. Preserve both extended horns, outer radius8, native bounds, placement and Regular1.70. Fit inner centerline radius6.52 through the unchanged horns. Filled uses the exact Regular exterior: outer radius8.85, inner radius5.67 and round .85 horn joins. The visible concave midpoint is11.73755556 12.26244444, beyond12,12 toward the crescent body; the center is inside the opening in both styles. Both styles remain pending owner review. The new inner-circle center is 15.74685101 8.25314899. Native margins remain3.20252287.17 of20 pairs remain approved.

Moon concavity centered at local0,0 (2026-10-27), superseding beyond-center revision: Owner clarified the concavity target: its deepest visible edge must coincide exactly with the icon center, treated as local0,0. Preserve both extended horns, outer radius8, position, native bounds, Regular1.70 and round .85 joins. Fit inner centerline radius6.569189459166889 so its inward visible edge at Regular1.70 reaches12,12 exactly. Filled is the exact Regular exterior: outer radius8.85, inner radius5.719189459166889 and .85 horn joins. Centerline midpoint11.39895924 12.60104076; shared visible concave midpoint12 12. Both styles remain pending owner review. The new inner-circle center is 16.04407765 7.95592235. Native margins remain3.20252287.17 of20 pairs remain approved.

Moon concave point moved to local2,2 (2026-10-27), superseding the circle-center interpretation: Owner corrected the interpretation: move the concave edge point, not the circle center, to local2,2 relative to the artboard center. The requested visible edge point is14,14. Translate the existing concave circle by+2,+2; preserve outer-circle center12.05252287 11.94747713, outer radius8, inner centerline radius6.569189459166889, Regular1.70 and round .85 joins. Recompute both horn intersections with the fixed outer circle. Filled uses exact outer8.85 and inner5.719189459166889 offsets and .85 joins. Do not recenter the result, because that would move the requested point away from local2,2. Native visible margins are left3.20252287/right4.51829225/top3.09747713/bottom3.20252287. This asymmetry is the intentional result of the requested notch translation. Both styles remain pending owner review. The new inner-circle center is 18.04407765 9.95592235.17 of20 pairs remain approved.
