export type CornerId = 'tl' | 'tr' | 'br' | 'bl';
export type CornerCommand =
  | { kind: 'M' | 'L'; x: number; y: number }
  | {
      kind: 'A';
      rx: number;
      ry: number;
      rotation: number;
      large: boolean;
      sweep: boolean;
      x: number;
      y: number;
    }
  | { kind: 'Z' };
export type CornerDrawing = { outline: string; filled: string };
export type MaximizeMinimizeGeometry = {
  strokeWidth: number;
  filledStrokeWidth: number;
  cornerRadius: number;
  corners: {
    id: CornerId;
    center: [number, number];
    direction: 1 | -1;
    outline: CornerCommand[];
    filled: CornerCommand[];
    maximize: CornerDrawing;
    minimize: CornerDrawing;
  }[];
  maximize: CornerDrawing;
  minimize: CornerDrawing;
};
const format = (n: number) => String(Math.round(n * 1e8) / 1e8);
/** Rigidly rotate circular-arc geometry; stroke/cap/elbow radii never scale. */
export function rotateCornerPath(
  commands: CornerCommand[],
  center: [number, number],
  angle: number,
): string {
  const cosine = Math.cos(angle),
    sine = Math.sin(angle);
  return commands
    .map((command) => {
      if (command.kind === 'Z') return 'Z';
      const x = center[0] + (command.x - center[0]) * cosine - (command.y - center[1]) * sine;
      const y = center[1] + (command.x - center[0]) * sine + (command.y - center[1]) * cosine;
      const point = `${format(x)} ${format(y)}`;
      if (command.kind !== 'A') return command.kind + point;
      return `A${format(command.rx)} ${format(command.ry)} ${format(command.rotation)} ${Number(command.large)} ${Number(command.sweep)} ${point}`;
    })
    .join(' ');
}
/** Four mirrored local half-turns preserve the same coordinated parts both ways. */
export function maximizeMinimizeFrame(progress: number, geometry: MaximizeMinimizeGeometry) {
  const p = Math.max(0, Math.min(1, Number.isFinite(progress) ? progress : 0));
  if (p === 0)
    return {
      ...geometry.maximize,
      parts: geometry.corners.map((corner) => ({ id: corner.id, ...corner.maximize })),
    };
  if (p === 1)
    return {
      ...geometry.minimize,
      parts: geometry.corners.map((corner) => ({ id: corner.id, ...corner.minimize })),
    };
  const eased = p ** 3 * (10 + p * (-15 + 6 * p));
  const parts = geometry.corners.map((corner) => {
    const angle = corner.direction * Math.PI * eased;
    return {
      id: corner.id,
      outline: rotateCornerPath(corner.outline, corner.center, angle),
      filled: rotateCornerPath(corner.filled, corner.center, angle),
    };
  });
  return {
    outline: parts.map((part) => part.outline).join(' '),
    filled: parts.map((part) => part.filled).join(' '),
    parts,
  };
}
