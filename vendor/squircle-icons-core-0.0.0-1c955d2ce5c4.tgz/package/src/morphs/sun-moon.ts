/** Experimental shared-circle construction. Static approved drawings stay unchanged. */
export type Circle = { x: number; y: number; radius: number };
export type SunMoonGeometry = {
  sun: Circle & { rays: number[][]; path: string; filledPath: string };
  moon: { outer: Circle; inner: Circle; path: string; filledPath: string };
  strokeWidth: number;
};
export type SunMoonFrame = { body: string; rays: string[]; rayOpacity: number };

const clamp = (value: number) => Math.min(1, Math.max(0, Number.isFinite(value) ? value : 0));
const mix = (a: number, b: number, p: number) => a + (b - a) * p;
// C2 continuity at the geometry phase boundaries, including the disappearing rays.
const smooth = (t: number) => t * t * t * (t * (t * 6 - 15) + 10);
const number = (value: number) => String(Math.round(value * 1e8) / 1e8);
const point = (x: number, y: number) => `${number(x)} ${number(y)}`;

export function sunMoonFrame(progress: number, geometry: SunMoonGeometry): SunMoonFrame {
  const p = clamp(progress);
  const bodyProgress = smooth(p);
  const rayProgress = smooth(clamp(p / 0.48));
  const { sun, moon } = geometry;
  const x = mix(sun.x, moon.outer.x, bodyProgress);
  const y = mix(sun.y, moon.outer.y, bodyProgress);
  const radius = mix(sun.radius, moon.outer.radius, bodyProgress);
  const innerRadius = moon.inner.radius;
  const direction = Math.atan2(moon.inner.y - moon.outer.y, moon.inner.x - moon.outer.x);
  const finalDistance = Math.hypot(moon.inner.x - moon.outer.x, moon.inner.y - moon.outer.y);
  // Squared overlap avoids the sqrt-speed singularity when two circles first touch.
  const overlap = (moon.outer.radius + innerRadius - finalDistance) * bodyProgress ** 2;
  const distance = radius + innerRadius - overlap;
  let body: string;
  if (p === 0) {
    body = sun.path;
  } else if (p === 1) {
    body = moon.path;
  } else if (overlap < 1e-7) {
    body = `M${point(x + radius, y)} A${number(radius)} ${number(radius)} 0 1 0 ${point(x - radius, y)} A${number(radius)} ${number(radius)} 0 1 0 ${point(x + radius, y)} Z`;
  } else {
    const ux = Math.cos(direction);
    const uy = Math.sin(direction);
    const a = (radius ** 2 - innerRadius ** 2 + distance ** 2) / (2 * distance);
    const height = Math.sqrt(Math.max(0, radius ** 2 - a ** 2));
    const mx = x + a * ux;
    const my = y + a * uy;
    const start = point(mx + height * uy, my - height * ux);
    const end = point(mx - height * uy, my + height * ux);
    body = `M${start} A${number(radius)} ${number(radius)} 0 1 0 ${end} A${number(innerRadius)} ${number(innerRadius)} 0 0 1 ${start} Z`;
  }
  const rays = sun.rays.map(([x1, y1, x2, y2]) => {
    if (p === 0) return `M${point(x1, y1)} L${point(x2, y2)}`;
    const angle = Math.atan2(y1 - sun.y, x1 - sun.x) + (Math.PI / 4) * rayProgress;
    const near = mix(Math.hypot(x1 - sun.x, y1 - sun.y), radius + 0.4, rayProgress);
    const far = near + Math.hypot(x2 - x1, y2 - y1) * (1 - rayProgress);
    return `M${point(x + near * Math.cos(angle), y + near * Math.sin(angle))} L${point(x + far * Math.cos(angle), y + far * Math.sin(angle))}`;
  });
  return { body, rays, rayOpacity: 1 - rayProgress };
}
