import { mergedStrokes, movingStrokeUnion } from './round-strokes.js';
export type MenuXMarkGeometry = {
  center: [number, number];
  menuExtent: number;
  menuOffset: number;
  xExtent: number;
  strokeWidth: number;
  filledStrokeWidth: number;
  menu: { outline: string; filled: string };
  x: { outline: string; filled: string };
};
export type MenuXGeometry = MenuXMarkGeometry;
const clamp = (p: number) => Math.max(0, Math.min(1, p));
const smooth = (p: number) => {
  const t = clamp(p);
  return t ** 3 * (10 + t * (-15 + 6 * t));
};
const mix = (a: number, b: number, p: number) => a + (b - a) * p;
const fmt = (n: number) => String(Math.round(n * 1e8) / 1e8);
const point = (p: [number, number]) => p.map(fmt).join(' ');
export function menuXFrame(progress: number, geometry: MenuXGeometry) {
  const mark = geometry;
  const p = clamp(Number.isFinite(progress) ? progress : 0);
  if (p === 0) return { ...mark.menu, filled: mark.menu.filled, middle: '', middleWidth: 0 };
  if (p === 1) return { ...mark.x, filled: mark.x.filled, middle: '', middleWidth: 0 };
  const center = mark.center;
  // Finish the horizontal merge before either outer bar starts opening into X.
  const collapse = smooth(p * 2);
  const opening = smooth(p * 2 - 1);
  const offset = mark.menuOffset * (1 - collapse);
  const angle = (Math.PI / 4) * opening;
  const extent = mix(mark.menuExtent, mark.xExtent, opening) / Math.cos(angle);
  const line = (cy: number, a: number) => {
    const dx = Math.cos(a) * extent,
      dy = Math.sin(a) * extent;
    return `M${point([center[0] - dx, cy - dy])} L${point([center[0] + dx, cy + dy])}`;
  };
  const remaining = 1 - collapse;
  const middleExtent = mark.menuExtent * remaining;
  const width = mark.filledStrokeWidth;
  const glyph =
    offset < 1e-6 && remaining < 1e-6
      ? mergedStrokes(angle, -angle, extent, width / 2, { x: center[0], y: center[1] })
      : movingStrokeUnion([
          {
            center: { x: center[0], y: center[1] - offset },
            angle,
            length: extent,
            radius: width / 2,
          },
          {
            center: { x: center[0], y: center[1] + offset },
            angle: -angle,
            length: extent,
            radius: width / 2,
          },
          {
            center: { x: center[0], y: center[1] },
            angle: 0,
            length: middleExtent,
            radius: (width / 2) * remaining,
          },
        ]);
  return {
    outline:
      offset === 0 && angle === 0
        ? line(center[1], 0)
        : `${line(center[1] - offset, angle)} ${line(center[1] + offset, -angle)}`,
    middle:
      remaining > 1e-7
        ? `M${point([center[0] - middleExtent, center[1]])} H${fmt(center[0] + middleExtent)}`
        : '',
    middleWidth: mark.strokeWidth * remaining,
    filledWidth: width,
    filled: glyph,
  };
}
